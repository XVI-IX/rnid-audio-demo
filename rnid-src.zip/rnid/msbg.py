"""Full-timeline adapter for the Cambridge MSBG hearing-loss model."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
import math
import os
import sys

import numpy as np
from clarity.evaluator.msbg import cochlea as _cochlea
from clarity.evaluator.msbg import msbg_utils as _msbg_utils
from clarity.evaluator.msbg.msbg import Ear
from scipy import signal as _signal
from clarity.utils.audiogram import Audiogram

from .audio import CHANNELS, SAMPLE_RATE
from .errors import RNIDError

GUARD_BEFORE = SAMPLE_RATE // 10
GUARD_AFTER = SAMPLE_RATE // 10
RMS_WINDOW = SAMPLE_RATE // 100
ACTIVE_RELATIVE_DB = -12.0
ACTIVE_FLOOR_DBFS = -80.0
IMPULSE_SAMPLE = SAMPLE_RATE // 2

# Identifies how a channel's digital level becomes the level MSBG simulates. With the
# pinned model, each ear's active RMS is presented at equiv_0db_spl + ahr + the overall
# RMS in dBFS of the guarded channel. MSBG keeps that rescale (model_rescale_db) in its
# output; v2 undoes it on the output, so the simulated file's level differs from the
# reference only by the modelled hearing loss. v1 left it in.
# Version any change to guards, scaling or the model's level handling under a new name.
LEVEL_CONVENTION = "msbg_0.9.0_overall_rms_guarded_v2"

# MSBG's processing path colours the sound even with no hearing loss, mainly because its
# gammatone filterbanks start at 66-83 Hz: with 0 dB HL the output is 7-18 dB down below
# 50 Hz (36-channel bank), and the 19-channel bank adds a 1-2.5 dB bump from 100 Hz to
# 1 kHz. RNID measures each filterbank's no-loss path (outer/middle-ear filters, filterbank
# and recombination; no smearing or recruitment) and applies the inverse as a minimum-phase
# filter, so a no-loss render is flat from 20 Hz to 16 kHz. Hearing-loss effects are left
# as the model produces them, and the deliberate 18 kHz low-pass is kept.
PATH_COMPENSATION = "msbg_filterbank_path_eq_v1"
COMPENSATION_BAND_HZ = (20.0, 16000.0)
COMPENSATION_TAPER_HZ = (10.0, 18000.0)
COMPENSATION_LIMITS_DB = (-6.0, 18.0)

_UPSTREAM_GENERATE_KEY_PERCENT = _msbg_utils.generate_key_percent


def _generate_key_percent(
    signal: np.ndarray,
    threshold_db: float,
    window_length: int,
    percent_to_track: float | None = None,
) -> tuple[np.ndarray, float]:
    """Vectorised equivalent of upstream ``generate_key_percent`` for a fixed threshold.

    Upstream copies its index array once per active 10 ms frame, which is quadratic in
    duration and took about 68 s per ear on a 120 s clip. This version returns an
    identical key array and threshold, so MSBG output is unchanged; the test suite
    checks that against the pinned upstream function.
    """
    if percent_to_track is not None:
        return _UPSTREAM_GENERATE_KEY_PERCENT(signal, threshold_db, window_length, percent_to_track)
    window_length = int(window_length)
    signal = signal.flatten()
    total_frames = len(signal) // window_length
    non_zero = np.power(10, (threshold_db - 30) / 10)
    frames = signal[: total_frames * window_length].astype("float").reshape(total_frames, window_length)
    every_db = 10 * np.log10(non_zero + np.sum(np.power(frames, 2), axis=1) / window_length)
    np.histogram(every_db, 140)  # Upstream computes it; keep its failure behaviour.
    frame_index = np.nonzero(every_db >= threshold_db)[0]
    key = (frame_index[:, None] * window_length + np.arange(window_length)).ravel().astype(float)
    return key, threshold_db


# MSBG reaches this through measure_rms, which resolves it from the module namespace.
_msbg_utils.generate_key_percent = _generate_key_percent

_UPSTREAM_COCHLEA_SIMULATE = _cochlea.Cochlea.simulate


def _simulate_by_channel(self: _cochlea.Cochlea, coch_sig: np.ndarray, equiv_0dB_file_SPL: float) -> np.ndarray:
    """Same steps as upstream ``Cochlea.simulate``, one filterbank channel at a time.

    Upstream holds every channel and its envelope for the whole clip, about 576 bytes per
    sample: 3 GiB for two minutes. Each channel here is filtered, enveloped and recruited
    with the upstream functions, then added to a running total in the same order that
    upstream's sum uses, so the output is unchanged; the test suite checks it against the
    pinned implementation.
    """
    if self.smearer is not None:
        coch_sig = self.smearer.smear(coch_sig)
    params = self.gtfbank_params
    nums, denoms = np.array(params["GTn_nums"]), np.array(params["GTn_denoms"])
    hp_nums, hp_denoms = np.array(params["HP_nums"]), np.array(params["HP_denoms"])
    delays, centres = np.array(params["GTnDelays"]), np.array(params["ERBn_CentFrq"])
    start2pole = params["Start2PoleHP"]
    n_samples = len(coch_sig)
    total = None
    for channel in range(denoms.shape[0]):
        # The body of upstream gammatone_filterbank for one channel.
        band = coch_sig
        for _ in range(params["NGAMMA"]):
            band = _signal.lfilter(nums[channel, :], denoms[channel, :], band)
        delay = delays[channel]
        band[np.arange(0, n_samples - delay)] = band[np.arange(delay, n_samples)]
        band[np.arange(n_samples - delay, n_samples)] = 0
        if channel >= start2pole - 1:
            hp = channel - start2pole + 1
            band = _signal.lfilter(hp_nums[hp, :], hp_denoms[hp, :], band)
        band = band[np.newaxis, :]
        envelope = _cochlea.compute_envelope(band, centres[channel:channel + 1], self.fs)
        band = _cochlea.recruitment(
            band, envelope, equiv_0dB_file_SPL,
            self.cf_expansion[channel:channel + 1], self.eq_loud_db_catch_up[channel:channel + 1],
        )[0]
        total = band.copy() if total is None else total + band
    return total * np.power(10, -0.05 * params["Recombination_dB"])


_cochlea.Cochlea.simulate = _simulate_by_channel


def severity(audiogram: Mapping[str, Sequence[float]]) -> str:
    """Return the MSBG severity class, which selects the filterbank, smearing and delay."""
    return Audiogram(
        frequencies=np.asarray(audiogram["frequencies_hz"], dtype=float),
        levels=np.asarray(audiogram["thresholds_db_hl"], dtype=float),
    ).severity


def _has_active_frame(signal_power: np.ndarray, input_rms_dbfs: float | None) -> bool:
    """Check the pinned model's active RMS gate before asking it to divide by active length."""
    if input_rms_dbfs is None:
        return False
    # MSBG uses complete 10 ms windows and a power offset 30 dB below the gate.
    gate = max(input_rms_dbfs + ACTIVE_RELATIVE_DB, ACTIVE_FLOOR_DBFS)
    complete_samples = len(signal_power) // RMS_WINDOW * RMS_WINDOW
    frame_power = signal_power[:complete_samples].reshape(-1, RMS_WINDOW).mean(axis=1)
    frame_db = 10 * np.log10(10 ** ((gate - 30) / 10) + frame_power)
    return bool(np.any(frame_db >= gate))


def _model_level(signal: np.ndarray, input_rms_dbfs: float, model_settings: Mapping) -> dict:
    """Repeat the level arithmetic in ``Ear.process`` for one audible channel."""
    active_rms, *_ = _msbg_utils.measure_rms(signal, SAMPLE_RATE, ACTIVE_RELATIVE_DB)
    active_rms_dbfs = 20 * math.log10(active_rms)
    return {
        "active_rms_dbfs": active_rms_dbfs,
        "model_input_level_db_spl": (
            float(model_settings["equiv_0db_spl"]) + float(model_settings["ahr"]) + input_rms_dbfs
        ),
        "model_rescale_db": input_rms_dbfs - active_rms_dbfs,
    }


def _new_ear(
    frequencies: tuple[float, ...],
    thresholds: tuple[float, ...],
    src_pos: str,
    equiv_0db_spl: float,
    ahr: float,
) -> Ear:
    try:
        ear = Ear(sample_rate=SAMPLE_RATE, src_pos=src_pos, equiv_0db_spl=equiv_0db_spl, ahr=ahr)
        ear.set_audiogram(
            Audiogram(frequencies=np.asarray(frequencies), levels=np.asarray(thresholds))
        )
    except Exception as exc:
        raise RNIDError("MODEL_ERROR", "MSBG could not load the hearing profile.") from exc
    return ear


def _process_ear(ear: Ear, samples: np.ndarray) -> np.ndarray:
    try:
        processed = np.asarray(ear.process(samples, add_calibration=False)[0])
    except Exception as exc:
        raise RNIDError("MODEL_ERROR", "MSBG could not process the audio channel.") from exc
    if processed.ndim != 1 or not len(processed) or not np.isfinite(processed).all():
        raise RNIDError("MODEL_ERROR", "MSBG produced invalid samples for an audible channel.")
    return processed


def _ear_config(
    profile: Mapping[str, Sequence[float]], model_settings: Mapping[str, str | float]
) -> tuple:
    return (
        tuple(profile["frequencies_hz"]),
        tuple(profile["thresholds_db_hl"]),
        str(model_settings["src_pos"]),
        float(model_settings["equiv_0db_spl"]),
        float(model_settings["ahr"]),
    )


def path_response_db(src_pos: str, gtfbank_file: str) -> tuple[np.ndarray, np.ndarray]:
    """No-loss response of MSBG's processing path for one filterbank, in dB on an FFT grid."""
    size = 1 << 16
    impulse = np.zeros(size)
    impulse[size // 4] = 1.0
    cochlea = _cochlea.Cochlea(audiogram=Audiogram(levels=np.zeros(2), frequencies=np.array([1000.0, 4000.0])))
    cochlea.gtfbank_params = _msbg_utils.read_gtf_file(f"msbg_hparams/{gtfbank_file}.json")
    channels = len(cochlea.gtfbank_params["GTn_CentFrq"])
    cochlea.cf_expansion = np.ones(channels)  # unity recruitment
    cochlea.eq_loud_db_catch_up = 105.0 * np.ones(channels)
    cochlea.smearer = None
    correction = Ear.get_src_correction(src_pos)
    forward = Ear.src_to_cochlea_filt(impulse[np.newaxis, :], correction, SAMPLE_RATE)[0]
    response = Ear.src_to_cochlea_filt(
        cochlea.simulate(forward, 100.0)[np.newaxis, :], correction, SAMPLE_RATE, backward=True,
    )[0]
    frequencies = np.fft.rfftfreq(size, 1 / SAMPLE_RATE)
    return frequencies, 10 * np.log10(np.maximum(np.abs(np.fft.rfft(response)) ** 2, 1e-30))


@lru_cache(maxsize=16)
def _path_compensation(src_pos: str, gtfbank_file: str) -> np.ndarray:
    """Minimum-phase FIR that makes the no-loss path flat over COMPENSATION_BAND_HZ."""
    from .filters import _NFFT, _minimum_phase

    frequencies, power_db = path_response_db(src_pos, gtfbank_file)
    grid = np.fft.rfftfreq(_NFFT, 1 / SAMPLE_RATE)
    half_band = 2 ** (0.5 / 6)  # 1/6-octave smoothing, in power
    centres = np.maximum(grid, COMPENSATION_TAPER_HZ[0])
    cumulative = np.concatenate(([0.0], np.cumsum(10 ** (power_db / 10))))
    lo = np.searchsorted(frequencies, centres / half_band, side="left")
    hi = np.maximum(np.searchsorted(frequencies, centres * half_band, side="right"), lo + 1)
    smoothed = 10 * np.log10((cumulative[hi] - cumulative[lo]) / (hi - lo))
    low, high = COMPENSATION_BAND_HZ
    taper_low, taper_high = COMPENSATION_TAPER_HZ
    safe = np.maximum(grid, 1.0)
    weight = np.clip(np.log(safe / taper_low) / np.log(low / taper_low), 0, 1)
    weight *= np.clip(np.log(taper_high / safe) / np.log(taper_high / high), 0, 1)
    gain_db = weight * np.clip(-smoothed, *COMPENSATION_LIMITS_DB)
    response = _minimum_phase(gain_db)
    response.setflags(write=False)
    return response


def _compensate(processed: np.ndarray, config: tuple) -> np.ndarray:
    """Apply the path compensation for this ear's filterbank, keeping the length."""
    frequencies, thresholds, src_pos = config[:3]
    gtfbank = _cochlea.HL_PARAMS[
        severity({"frequencies_hz": frequencies, "thresholds_db_hl": thresholds})
    ]["gtfbank_file"]
    return _signal.oaconvolve(processed, _path_compensation(src_pos, gtfbank))[: len(processed)]


@lru_cache(maxsize=64)
def _offset(
    frequencies: tuple[float, ...],
    thresholds: tuple[float, ...],
    src_pos: str,
    equiv_0db_spl: float,
    ahr: float,
) -> int:
    config = (frequencies, thresholds, src_pos, equiv_0db_spl, ahr)
    ear = _new_ear(*config)
    # The peak of a central unit impulse through the compensated path sets the offset.
    test = np.zeros(GUARD_BEFORE + SAMPLE_RATE + GUARD_AFTER, dtype=np.float64)
    impulse = GUARD_BEFORE + IMPULSE_SAMPLE
    test[impulse] = 1.0
    response = np.abs(_compensate(_process_ear(ear, test), config))
    peak = int(np.argmax(response))
    delay = peak - impulse
    if response[peak] == 0 or not 0 <= delay <= GUARD_AFTER:
        raise RNIDError("MODEL_ERROR", "MSBG delay calibration did not yield a valid offset.")
    return delay


def check_profile(
    left: Mapping[str, Sequence[float]],
    right: Mapping[str, Sequence[float]],
    model_settings: Mapping[str, str | float],
) -> dict:
    """Load both ears into MSBG and measure their offsets without rendering audio."""
    result = {"severity": {}, "offset_samples": {}}
    for side, profile in (("left", left), ("right", right)):
        result["severity"][side] = severity(profile)
        result["offset_samples"][side] = _offset(*_ear_config(profile, model_settings))
    return result


WASM_CHUNK_SAMPLES = 30 * SAMPLE_RATE
WASM_OVERLAP_SAMPLES = SAMPLE_RATE


def _process_ear_wasm_chunked(ear: Ear, samples: np.ndarray, rescale_db: float) -> np.ndarray:
    """Process long Wasm32 signals in 30s overlap-crossfaded windows using whole-track SPL."""
    from clarity.evaluator.msbg.msbg import UPPER_CUTOFF_HZ

    scaled = samples * (10.0 ** (0.05 * rescale_db))
    equiv_0db_spl = ear.equiv_0db_spl + ear.ahr
    winlen = 2 * math.floor(0.0015 * SAMPLE_RATE) + 1
    lpf44d1 = _signal.firwin(winlen, UPPER_CUTOFF_HZ / int(SAMPLE_RATE / 2), window=("kaiser", 8))

    total = len(scaled)
    out = np.zeros(total, dtype=np.float64)
    step = WASM_CHUNK_SAMPLES
    pad = WASM_OVERLAP_SAMPLES
    fade_len = SAMPLE_RATE // 10  # 100 ms linear crossfade inside overlap guard

    pos = 0
    while pos < total:
        core_end = min(total, pos + step)
        win_start = max(0, pos - pad)
        win_end = min(total, core_end + pad)

        seg = scaled[win_start:win_end][np.newaxis, :]
        seg = Ear.src_to_cochlea_filt(seg, ear.src_correction, SAMPLE_RATE)
        if ear.cochlea is not None:
            seg = np.array([ear.cochlea.simulate(x, equiv_0db_spl) for x in seg])
        seg = Ear.src_to_cochlea_filt(seg, ear.src_correction, SAMPLE_RATE, backward=True)
        seg_out = np.asarray(_signal.lfilter(lpf44d1, 1, seg[0]), dtype=np.float64)

        local_start = pos - win_start
        local_end = local_start + (core_end - pos)
        core = seg_out[local_start:local_end]

        if pos == 0:
            out[pos:core_end] = core
        else:
            # Smoothly blend across `fade_len` samples just before `pos`
            blend = min(fade_len, local_start, pos)
            if blend > 0:
                prev_tail = seg_out[local_start - blend : local_start]
                w = np.linspace(0.0, 1.0, blend, endpoint=False)
                out[pos - blend : pos] = out[pos - blend : pos] * (1.0 - w) + prev_tail * w
            out[pos:core_end] = core

        pos = core_end

    if not np.isfinite(out).all():
        raise RNIDError("MODEL_ERROR", "MSBG produced invalid samples for an audible channel.")
    return out


def _render_audible_ear(
    config: tuple, signal: np.ndarray, rescale_db: float, offset: int, length: int
) -> np.ndarray:
    ear = _new_ear(*config)
    if sys.platform == "emscripten" and len(signal) > 35 * SAMPLE_RATE:
        processed = _process_ear_wasm_chunked(ear, signal, rescale_db)
    else:
        processed = _process_ear(ear, signal)
    # v2: undo MSBG's internal rescale, then flatten the no-loss processing path.
    processed *= 10 ** (-rescale_db / 20)
    processed = _compensate(processed, config)
    start = GUARD_BEFORE + offset
    end = start + length
    if end > len(processed):
        raise RNIDError("MODEL_ERROR", "MSBG output does not cover the source timeline.")
    return processed[start:end]


def _use_parallel_ears(frame_count: int, bypassed: Mapping[str, bool]) -> bool:
    if bypassed["left"] or bypassed["right"] or sys.platform == "emscripten" or frame_count < SAMPLE_RATE:
        return False
    workers = os.environ.get("RNID_EAR_WORKERS", "2").strip()
    return workers != "1" and (os.cpu_count() or 1) >= 2


def render(
    samples: np.ndarray,
    left: Mapping[str, Sequence[float]],
    right: Mapping[str, Sequence[float]],
    model_settings: Mapping[str, str | float],
) -> tuple[np.ndarray, dict]:
    """Apply the configured ear profiles and return the aligned pair of simulated channels."""
    if (
        samples.ndim != 2 or samples.shape[1] != CHANNELS
        or not len(samples) or not np.isfinite(samples).all()
    ):
        raise RNIDError("INVALID_AUDIO", "MSBG requires finite stereo samples on the canonical timeline.")
    result = np.zeros(samples.shape, dtype=np.float64)
    offsets: dict[str, int] = {}
    rms: dict[str, float | None] = {}
    bypassed: dict[str, bool] = {}
    severities: dict[str, str] = {}
    levels: dict[str, dict[str, float | None]] = {
        "active_rms_dbfs": {}, "model_input_level_db_spl": {}, "model_rescale_db": {},
    }
    ear_jobs: list[tuple[int, tuple, np.ndarray, float, int]] = []
    for index, (side, profile) in enumerate((("left", left), ("right", right))):
        config = _ear_config(profile, model_settings)
        severities[side] = severity(profile)
        # Warm per-ear offset and path-compensation caches sequentially before any threads run.
        offsets[side] = _offset(*config)
        signal = np.pad(samples[:, index].astype(np.float64), (GUARD_BEFORE, GUARD_AFTER))
        power = np.square(signal)
        mean_power = float(power.mean())
        rms[side] = float(10 * np.log10(mean_power)) if mean_power else None
        bypassed[side] = not _has_active_frame(power, rms[side])
        del power
        if bypassed[side]:
            for values in levels.values():
                values[side] = None
            continue
        for name, value in _model_level(signal, rms[side], model_settings).items():
            levels[name][side] = value
        ear_jobs.append((index, config, signal, float(levels["model_rescale_db"][side]), offsets[side]))

    if len(ear_jobs) == 2 and _use_parallel_ears(len(samples), bypassed):
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [
                (index, pool.submit(_render_audible_ear, config, signal, rescale_db, offset, len(samples)))
                for index, config, signal, rescale_db, offset in ear_jobs
            ]
            for index, future in futures:
                result[:, index] = future.result()
    else:
        for index, config, signal, rescale_db, offset in ear_jobs:
            result[:, index] = _render_audible_ear(config, signal, rescale_db, offset, len(samples))

    return result, {
        "input_rms_dbfs": rms,
        "offset_samples": offsets,
        "bypassed_silent": bypassed,
        "guard_samples": {"before": GUARD_BEFORE, "after": GUARD_AFTER},
        "severity": severities,
        "level_convention": LEVEL_CONVENTION,
        "path_compensation": PATH_COMPENSATION,
        **levels,
    }
