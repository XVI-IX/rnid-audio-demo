"""Command-line entry point for the RNID renderer."""

import argparse
import json
import sys
import tempfile
from pathlib import Path

from . import __version__
from .errors import RNIDError
from .profiles import load_registry


class Parser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise RNIDError("INVALID_ARGUMENTS", message)


def _parser() -> argparse.ArgumentParser:
    parser = Parser(prog="rnid")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    commands = parser.add_subparsers(dest="command", required=True)

    profiles = commands.add_parser("profiles", help="Show available profiles")
    profile_commands = profiles.add_subparsers(dest="profile_command", required=True)
    listing = profile_commands.add_parser("list")
    listing.add_argument("--json", action="store_true", dest="as_json")
    validation = profile_commands.add_parser(
        "validate", help="Check candidate profile files and load them into MSBG"
    )
    validation.add_argument("paths", nargs="+", type=Path)

    filters = commands.add_parser("filters", help="Export hearing-loss filters as impulse responses")
    filter_commands = filters.add_subparsers(dest="filter_command", required=True)
    export = filter_commands.add_parser(
        "export", help="Write a stereo impulse-response WAV and its description for each profile"
    )
    chosen = export.add_mutually_exclusive_group(required=True)
    chosen.add_argument("--profile", action="append", dest="profiles")
    chosen.add_argument("--all", action="store_true")
    export.add_argument("--out-dir", required=True, type=Path)
    export.add_argument(
        "--level-dbfs", type=float, default=-20.0,
        help="Input RMS level the filter is designed for (default -20 dBFS)",
    )

    conversion = commands.add_parser("convert", help="Render a time-aligned WAV comparison")
    conversion.add_argument("input", type=Path)
    conversion.add_argument("--profile", required=True)
    conversion.add_argument("--out-dir", required=True, type=Path)
    conversion.add_argument("--detect-climax", action="store_true")
    conversion.add_argument(
        "--include-filter", action="store_true",
        help="Include an approximate stereo impulse response for this recording's input level",
    )
    manual = conversion.add_mutually_exclusive_group()
    manual.add_argument("--climax-seconds")
    manual.add_argument("--climax-sample")

    detection = commands.add_parser("detect-climax", help="Suggest transition markers on the source audio")
    detection.add_argument("input", type=Path)
    detection.add_argument("--out", required=True, type=Path)
    return parser


def _write_marker_file(path: Path, result: dict) -> None:
    try:
        with tempfile.TemporaryDirectory(prefix=".rnid-markers-", dir=path.absolute().parent) as temporary:
            staged = Path(temporary) / "markers.json"
            staged.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
            staged.replace(path)
    except OSError as error:
        raise RNIDError("EXPORT_FAILED", "The marker file could not be saved.") from error


def _validate(path: Path) -> dict:
    from .msbg import check_profile
    from .profiles import read_profile

    profile = read_profile(path)
    return {
        **profile.public(),
        "file": path.name,
        "digest": f"sha256:{profile.digest}",
        "provenance": profile.provenance,
        "calibration": dict(profile.model),
        **check_profile(profile.left, profile.right, profile.model),
    }


def _export_filters(registry: dict, args: argparse.Namespace) -> list[Path]:
    import math

    from . import PYCLARITY_VERSION
    from .filters import design, write

    level = args.level_dbfs
    if not math.isfinite(level) or not -60 <= level <= 0:
        raise RNIDError("INVALID_ARGUMENTS", "--level-dbfs must be between -60 and 0.")
    ids = list(registry) if args.all else list(dict.fromkeys(args.profiles))
    missing = [profile_id for profile_id in ids if profile_id not in registry]
    if missing:
        raise RNIDError("INVALID_PROFILE", f"Unavailable profile: {missing[0]}.")
    out_dir = args.out_dir.absolute()
    targets = [out_dir / f"{profile_id}-ir{suffix}" for profile_id in ids for suffix in (".wav", ".json")]
    if any(path.exists() or path.is_symlink() for path in targets):
        raise RNIDError("OUTPUT_EXISTS", "A filter file for one of these profiles already exists.")
    written = []
    try:
        out_dir.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix=".rnid-filters-", dir=out_dir) as temporary:
            staging = Path(temporary)
            for profile_id in ids:
                profile = registry[profile_id]
                response, info = design(
                    profile.left, profile.right, profile.model, {"left": level, "right": level}
                )
                wav, description = f"{profile_id}-ir.wav", f"{profile_id}-ir.json"
                write(staging / wav, response)
                (staging / description).write_text(json.dumps({
                    "profile": {
                        **profile.public(), "digest": f"sha256:{profile.digest}",
                        "provenance": profile.provenance, "calibration": dict(profile.model),
                    },
                    "filter": {"file": wav, **info},
                    "engine": {"name": "Cambridge MSBG", "rnid": __version__, "pyclarity": PYCLARITY_VERSION},
                }, indent=2, allow_nan=False) + "\n", encoding="utf-8")
            for name in sorted(path.name for path in staging.iterdir()):
                (staging / name).rename(out_dir / name)
                written.append(out_dir / name)
    except OSError as error:
        raise RNIDError("EXPORT_FAILED", "The filter files could not be saved.") from error
    return written


def main(argv: list[str] | None = None) -> int:
    try:
        args = _parser().parse_args(argv)
        if args.command == "detect-climax":
            from .audio import decode
            from .config import limits_from_env
            from .detection import analyse

            result = analyse(decode(args.input, limits_from_env()))
            _write_marker_file(args.out, result)
            return 0
        if args.command == "profiles" and args.profile_command == "validate":
            print(json.dumps([_validate(path) for path in args.paths], indent=2))
            return 0

        registry = load_registry()
        if args.command == "filters":
            for path in _export_filters(registry, args):
                print(path)
            return 0
        if args.command == "profiles":
            if args.as_json:
                print(json.dumps([profile.public() for profile in registry.values()]))
            else:
                for profile in registry.values():
                    print(f"{profile.id}\t{profile.version}\t{profile.review_status}\t{profile.label}")
            return 0

        profile = registry.get(args.profile)
        if profile is None:
            raise RNIDError("INVALID_PROFILE", "The requested profile is unavailable.")
        from .config import limits_from_env
        from .render import convert

        convert(
            args.input,
            profile,
            args.out_dir,
            limits=limits_from_env(),
            detect_climax=args.detect_climax,
            climax_seconds=args.climax_seconds,
            climax_sample=args.climax_sample,
            include_filter=args.include_filter,
        )
        print(args.out_dir / "manifest.json")
        return 0
    except RNIDError as error:
        print(json.dumps({"error": {"code": error.code, "message": error.message}}), file=sys.stderr)
        return 1
