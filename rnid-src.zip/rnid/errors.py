class RNIDError(Exception):
    """A stable machine-readable error and a short public message."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message
