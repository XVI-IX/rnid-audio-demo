"""Private, bounded HTTP access to the RNID converter."""

from __future__ import annotations

import asyncio
import fcntl
import importlib.util
import json
import logging
import math
import os
from pathlib import Path
import re
import secrets
import shutil
import signal
import stat
import sys
import tempfile
import time
import uuid
from collections.abc import AsyncIterator, Coroutine
from contextlib import aclosing, asynccontextmanager, suppress
from dataclasses import dataclass
from typing import Any, BinaryIO
from zipfile import ZIP_STORED, ZipFile

import anyio
from python_multipart import MultipartParser
from python_multipart.exceptions import MultipartParseError
from python_multipart.multipart import parse_options_header
from starlette.applications import Starlette
from starlette.concurrency import run_in_threadpool
from starlette.datastructures import Headers, MutableHeaders
from starlette.exceptions import HTTPException
from starlette.middleware import Middleware
from starlette.requests import ClientDisconnect, Request
from starlette.responses import JSONResponse, StreamingResponse
from starlette.routing import Route
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from .audio import ffmpeg_version
from .config import limits_from_env
from .errors import RNIDError
from .profiles import load_registry


LOGGER = logging.getLogger("rnid.service")
BUNDLE_FILES = ("reference.wav", "simulated.wav", "manifest.json")
REQUEST_PREFIX = "rnid-request-"
MULTIPART_OVERHEAD = 32 * 1024
CHUNK_BYTES = 256 * 1024
ERROR_HTTP_STATUS = {
    "INPUT_TOO_LARGE": 413,
    "DURATION_OUT_OF_RANGE": 413,
    "UNSUPPORTED_FORMAT": 415,
    "INVALID_AUDIO": 422,
    "INVALID_PROFILE": 422,
    "INVALID_MARKER": 422,
    "DETECTOR_DISABLED": 422,
    "PROCESSING_TIMEOUT": 504,
    "FFMPEG_UNAVAILABLE": 500,
    "EXPORT_FAILED": 500,
    "MODEL_ERROR": 500,
}


class APIError(Exception):
    def __init__(self, status: int, code: str, message: str, headers: dict[str, str] | None = None):
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.headers = headers

    def response(self, request_id: str) -> JSONResponse:
        return JSONResponse(
            {"error": {"code": self.code, "message": self.message, "request_id": request_id}},
            status_code=self.status,
            headers=self.headers,
        )


@dataclass(frozen=True)
class ServiceConfig:
    runtime_dir: Path
    token: bytes
    max_bytes: int
    process_timeout: float
    upload_timeout: float
    download_timeout: float
    stale_ttl: float

    @classmethod
    def from_env(cls) -> ServiceConfig:
        return cls(
            runtime_dir=Path(os.environ.get("RNID_RUNTIME_DIR", ".runtime/requests")).absolute(),
            token=read_token_file(),
            max_bytes=limits_from_env().max_bytes,
            process_timeout=positive_seconds("RNID_PROCESS_TIMEOUT_SECONDS", 360),
            upload_timeout=positive_seconds("RNID_UPLOAD_TIMEOUT_SECONDS", 30),
            download_timeout=positive_seconds("RNID_DOWNLOAD_TIMEOUT_SECONDS", 120),
            stale_ttl=positive_seconds("RNID_STALE_TTL_SECONDS", 3600),
        )


def positive_seconds(name: str, default: float) -> float:
    value = float(os.environ.get(name, default))
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be a positive number of seconds")
    return value


def read_token_file() -> bytes:
    location = os.environ.get("RNID_API_TOKEN_FILE")
    if not location:
        raise ValueError("RNID_API_TOKEN_FILE must point to a private token file")
    with os.fdopen(os.open(location, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW), "rb") as file:
        info = os.fstat(file.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise ValueError("The token file must be owned by the service user and private")
        token = file.read(260).rstrip(b"\r\n")
        if file.read(1) or re.fullmatch(rb"[A-Za-z0-9._~+/-]{32,256}={0,2}", token) is None:
            raise ValueError("The token file must contain a bearer token of at least 32 characters")
    return token


@dataclass
class RequestRecord:
    request_id: str
    profile_id: str | None = None
    audio_seconds: float | None = None
    process_seconds: float | None = None


class PrivateRequests:
    def __init__(self, app: ASGIApp, token: bytes):
        self.app = app
        self.token = token

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        record = RequestRecord(uuid.uuid4().hex)
        scope.setdefault("state", {})["record"] = record
        status = 499

        async def send_response(message: Message) -> None:
            nonlocal status
            if message["type"] == "http.response.start":
                status = message["status"]
                headers = MutableHeaders(scope=message)
                headers["X-Request-ID"] = record.request_id
                headers["Cache-Control"] = "no-store"
            await send(message)

        try:
            headers = Headers(scope=scope).getlist("authorization")
            if len(headers) == 1:
                scheme, _, provided = headers[0].encode("latin-1").partition(b" ")
            else:
                scheme, provided = b"", b""
            if scheme.lower() != b"bearer" or not secrets.compare_digest(provided, self.token):
                error = APIError(401, "UNAUTHORIZED", "A valid bearer token is required.", {"WWW-Authenticate": "Bearer"})
                await error.response(record.request_id)(scope, receive, send_response)
                return
            await self.app(scope, receive, send_response)
        finally:
            if scope["path"] == "/v1/convert" and scope["method"] == "POST":
                LOGGER.info(
                    "request_id=%s profile_id=%s audio_seconds=%s processing_seconds=%s status=%s",
                    record.request_id, record.profile_id, record.audio_seconds, record.process_seconds, status,
                )


class MultipartUpload:
    """Stream one audio file to a controlled path and retain bounded text fields."""

    TEXT_FIELDS = {b"profile_id", b"climax_seconds", b"detect_climax", b"include_filter"}

    def __init__(self, destination: BinaryIO, max_bytes: int):
        self.destination = destination
        self.max_bytes = max_bytes
        self.file_bytes = 0
        self.fields: dict[bytes, str] = {}
        self.part_name: bytes | None = None
        self.seen: set[bytes] = set()
        self.headers: dict[bytes, bytes] = {}
        self.header_name = bytearray()
        self.header_value = bytearray()
        self.value = bytearray()
        self.complete = False

    def part_begin(self) -> None:
        self.headers.clear()
        self.value.clear()

    def add_header_name(self, data: bytes, start: int, end: int) -> None:
        self.header_name.extend(data[start:end])

    def add_header_value(self, data: bytes, start: int, end: int) -> None:
        self.header_value.extend(data[start:end])

    def header_end(self) -> None:
        name = bytes(self.header_name).lower()
        if name in self.headers:
            raise APIError(422, "INVALID_REQUEST", "Multipart part headers must be unique.")
        self.headers[name] = bytes(self.header_value)
        self.header_name.clear()
        self.header_value.clear()

    def headers_finished(self) -> None:
        disposition, options = parse_options_header(self.headers.get(b"content-disposition"))
        name = options.get(b"name")
        if disposition != b"form-data" or name is None or name in self.seen:
            raise APIError(422, "INVALID_REQUEST", "Each multipart field must have a unique name.")
        if name == b"audio":
            if b"filename" not in options:
                raise APIError(422, "INVALID_REQUEST", "The audio field must be a file upload.")
        elif name not in self.TEXT_FIELDS or b"filename" in options:
            raise APIError(422, "INVALID_REQUEST", "Unexpected multipart field.")
        if b"content-transfer-encoding" in self.headers:
            raise APIError(422, "INVALID_REQUEST", "Upload the original audio bytes without transfer encoding.")
        self.seen.add(name)
        self.part_name = name

    def add_part_data(self, data: bytes, start: int, end: int) -> None:
        if self.part_name == b"audio":
            self.file_bytes += end - start
            if self.file_bytes > self.max_bytes:
                raise APIError(413, "INPUT_TOO_LARGE", "The uploaded audio exceeds the size limit.")
            self.destination.write(data[start:end])
        else:
            if len(self.value) + end - start > 1024:
                raise APIError(422, "INVALID_REQUEST", "Multipart text field exceeds the size limit.")
            self.value.extend(data[start:end])

    def part_end(self) -> None:
        name = self.part_name
        if name is not None and name in self.TEXT_FIELDS:
            self.fields[name] = self.value.decode("utf-8")

    def end(self) -> None:
        self.complete = True

    def parser(self, boundary: bytes) -> MultipartParser:
        return MultipartParser(boundary, {
            "on_part_begin": self.part_begin,
            "on_part_data": self.add_part_data,
            "on_part_end": self.part_end,
            "on_header_field": self.add_header_name,
            "on_header_value": self.add_header_value,
            "on_header_end": self.header_end,
            "on_headers_finished": self.headers_finished,
            "on_end": self.end,
        })


async def stage_upload(request: Request, destination: Path, config: ServiceConfig) -> dict[bytes, str]:
    max_body = config.max_bytes + MULTIPART_OVERHEAD
    length = request.headers.get("content-length")
    if length is not None:
        if not length.isascii() or not length.isdecimal() or len(length) > 20:
            raise APIError(422, "INVALID_REQUEST", "Invalid Content-Length header.")
        if int(length) > max_body:
            raise APIError(413, "INPUT_TOO_LARGE", "The upload exceeds the request size limit.")

    try:
        media_type, options = parse_options_header(request.headers.get("content-type"))
        boundary = options.get(b"boundary", b"")
        if media_type != b"multipart/form-data" or not 1 <= len(boundary) <= 70:
            raise APIError(422, "INVALID_REQUEST", "Use multipart/form-data with a valid boundary.")

        with destination.open("xb") as audio_file:
            upload = MultipartUpload(audio_file, config.max_bytes)
            parser = upload.parser(boundary)
            received_bytes = 0
            async with asyncio.timeout(config.upload_timeout):
                async for chunk in request.stream():
                    received_bytes += len(chunk)
                    if received_bytes > max_body:
                        raise APIError(413, "INPUT_TOO_LARGE", "The upload exceeds the request size limit.")
                    for start in range(0, len(chunk), CHUNK_BYTES):
                        await run_in_threadpool(parser.write, chunk[start:start + CHUNK_BYTES])
                parser.finalize()
    except (MultipartParseError, UnicodeError):
        raise APIError(422, "INVALID_REQUEST", "Malformed multipart data.") from None
    except TimeoutError:
        raise APIError(408, "UPLOAD_TIMEOUT", "The upload deadline expired.") from None

    if not upload.complete or b"audio" not in upload.seen or not upload.fields.get(b"profile_id"):
        raise APIError(422, "INVALID_REQUEST", "Complete audio and profile_id fields are required.")
    return upload.fields


def boolean_field(fields: dict[bytes, str], name: bytes) -> bool:
    value = fields.get(name, "false").lower()
    if value not in {"true", "false"}:
        raise APIError(422, "INVALID_REQUEST", f"{name.decode('ascii')} must be true or false.")
    return value == "true"


async def run_converter(
    source: Path, output: Path, profile_id: str, marker: str | None, detect: bool, config: ServiceConfig,
    *, include_filter: bool = False,
) -> None:
    args = [sys.executable, "-m", "rnid", "convert", str(source), "--profile", profile_id, "--out-dir", str(output)]
    if marker is not None:
        args.append(f"--climax-seconds={marker}")
    elif detect:
        args.append("--detect-climax")
    if include_filter:
        args.append("--include-filter")

    environment = dict(os.environ, TMPDIR=str(source.parent))
    for name in ("RNID_API_TOKEN", "RNID_API_TOKEN_FILE"):
        environment.pop(name, None)
    worker = await asyncio.create_subprocess_exec(
        *args, start_new_session=True, stdin=asyncio.subprocess.DEVNULL,
        stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE, env=environment,
    )
    try:
        async with asyncio.timeout(config.process_timeout):
            _, stderr = await worker.communicate()
    except (TimeoutError, asyncio.CancelledError) as exc:
        with suppress(ProcessLookupError):
            os.killpg(worker.pid, signal.SIGKILL)
        await worker.communicate()
        if isinstance(exc, asyncio.CancelledError):
            raise
        raise APIError(504, "PROCESSING_TIMEOUT", "The conversion exceeded its processing deadline.") from None

    if worker.returncode == 0:
        return
    try:
        error = json.loads(stderr.splitlines()[-1])["error"]
        code, message = error["code"], error["message"]
        status = ERROR_HTTP_STATUS[code]
        if isinstance(message, str) and len(message) <= 256:
            raise APIError(status, code, message)
    except (IndexError, KeyError, TypeError, ValueError):
        pass
    raise APIError(500, "CONVERSION_FAILED", "The renderer failed to produce an audio bundle.")


def pack_bundle(bundle: Path, archive: Path, include_filter: bool = False) -> float:
    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
    if ("filter" in manifest) != include_filter:
        raise ValueError("Unexpected filter metadata in render bundle")
    files = (*BUNDLE_FILES, "filter-ir.wav") if include_filter else BUNDLE_FILES
    with ZipFile(archive, "x", compression=ZIP_STORED) as result:
        for name in files:
            result.write(bundle / name, arcname=name)
    audio = manifest["audio"]
    return audio["frames"] / audio["sample_rate_hz"]


async def archive_chunks(path: Path) -> AsyncIterator[bytes]:
    async with await anyio.open_file(path, "rb") as file:
        while chunk := await file.read(CHUNK_BYTES):
            yield chunk


async def render_while_connected(request: Request, render: Coroutine[Any, Any, None]) -> None:
    async def wait_for_disconnect() -> None:
        while (await request.receive())["type"] != "http.disconnect":
            pass

    disconnect = asyncio.create_task(wait_for_disconnect())
    worker = asyncio.create_task(render)
    try:
        completed, _ = await asyncio.wait({disconnect, worker}, return_when=asyncio.FIRST_COMPLETED)
        if worker not in completed:
            await disconnect
            raise ClientDisconnect
        await worker
    finally:
        for task in (disconnect, worker):
            task.cancel()
        await asyncio.gather(disconnect, worker, return_exceptions=True)


class ConvertEndpoint:
    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        request = Request(scope, receive=receive)
        state = request.app.state
        record: RequestRecord = request.state.record
        config: ServiceConfig = state.config
        if state.active is not None:
            raise APIError(429, "CONVERSION_BUSY", "The conversion slot is occupied.", {"Retry-After": "5"})
        if not all(dependency_checks(state).values()):
            raise APIError(503, "SERVICE_UNAVAILABLE", "The conversion service is not ready.")

        try:
            with tempfile.TemporaryDirectory(dir=config.runtime_dir, prefix=REQUEST_PREFIX) as folder:
                workdir = Path(folder)
                state.active = workdir
                source, bundle, archive = workdir / "audio", workdir / "render", workdir / "rnid-render.zip"
                fields = await stage_upload(request, source, config)
                profile_id = fields[b"profile_id"]
                if profile_id not in state.registry:
                    raise APIError(422, "INVALID_PROFILE", "The requested profile is unavailable.")
                record.profile_id = profile_id
                detect = boolean_field(fields, b"detect_climax")
                include_filter = boolean_field(fields, b"include_filter")
                started = time.monotonic()
                try:
                    await render_while_connected(request, run_converter(
                        source, bundle, profile_id, fields.get(b"climax_seconds"), detect, config,
                        include_filter=include_filter,
                    ))
                    record.audio_seconds = await run_in_threadpool(pack_bundle, bundle, archive, include_filter)
                finally:
                    record.process_seconds = round(time.monotonic() - started, 3)

                async with aclosing(archive_chunks(archive)) as chunks:
                    response = StreamingResponse(chunks, media_type="application/zip", headers={
                        "Content-Disposition": 'attachment; filename="rnid-render.zip"',
                        "Content-Length": str(archive.stat().st_size),
                    })
                    try:
                        async with asyncio.timeout(config.download_timeout):
                            await response(scope, receive, send)
                    except TimeoutError:
                        LOGGER.info("request_id=%s download=timeout", record.request_id)
                        raise
        except ClientDisconnect:
            return
        except (KeyError, OSError, ValueError):
            raise APIError(500, "CONVERSION_FAILED", "The renderer could not stage or assemble the audio bundle.") from None
        finally:
            state.active = None


def dependency_checks(state) -> dict[str, bool]:
    config: ServiceConfig = state.config
    try:
        with tempfile.TemporaryFile(dir=config.runtime_dir):
            writable = True
    except OSError:
        writable = False
    return {
        "ffmpeg": state.ffmpeg_ready,
        "profile_registry": bool(state.registry),
        "model": state.model_ready,
        "temporary_storage": writable,
    }


async def health(request: Request) -> JSONResponse:
    checks = dependency_checks(request.app.state)
    ready = all(checks.values())
    return JSONResponse({"status": "ready" if ready else "unavailable", "checks": checks}, status_code=200 if ready else 503)


async def profiles(request: Request) -> JSONResponse:
    return JSONResponse({"profiles": [profile.public() for profile in request.app.state.registry.values()]})


async def api_error(request: Request, exc: APIError) -> JSONResponse:
    return exc.response(request.state.record.request_id)


async def routing_error(request: Request, exc: HTTPException) -> JSONResponse:
    code = {404: "NOT_FOUND", 405: "METHOD_NOT_ALLOWED"}.get(exc.status_code, "HTTP_ERROR")
    error = APIError(exc.status_code, code, exc.detail, exc.headers)
    return error.response(request.state.record.request_id)


def reap_stale_directories(state) -> None:
    cutoff = time.time() - state.config.stale_ttl
    for candidate in state.config.runtime_dir.glob(f"{REQUEST_PREFIX}*"):
        if candidate == state.active:
            continue
        try:
            info = candidate.lstat()
            if stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid() and info.st_mtime < cutoff:
                shutil.rmtree(candidate)
        except FileNotFoundError:
            pass
        except OSError:
            LOGGER.warning("A stale request directory could not be removed.")


async def reap_periodically(state) -> None:
    while True:
        await asyncio.sleep(min(state.config.stale_ttl, 300))
        reap_stale_directories(state)


@asynccontextmanager
async def lifespan(app: Starlette):
    state = app.state
    runtime_dir = state.config.runtime_dir
    runtime_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    info = runtime_dir.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise ValueError("RNID_RUNTIME_DIR must be a private directory owned by the service user")
    with (runtime_dir / ".service.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        state.registry = load_registry()
        try:
            state.ffmpeg_ready = bool(ffmpeg_version())
        except RNIDError:
            state.ffmpeg_ready = False
        state.model_ready = importlib.util.find_spec("clarity") is not None
        state.active = None
        reap_stale_directories(state)
        reaper = asyncio.create_task(reap_periodically(state))
        try:
            yield
        finally:
            reaper.cancel()
            with suppress(asyncio.CancelledError):
                await reaper


def create_app(config: ServiceConfig | None = None) -> Starlette:
    config = config or ServiceConfig.from_env()
    app = Starlette(
        routes=[
            Route("/healthz", health, methods=["GET"]),
            Route("/v1/profiles", profiles, methods=["GET"]),
            Route("/v1/convert", ConvertEndpoint(), methods=["POST"]),
        ],
        middleware=[Middleware(PrivateRequests, token=config.token)],
        exception_handlers={APIError: api_error, HTTPException: routing_error},
        lifespan=lifespan,
    )
    app.state.config = config
    return app


def main() -> None:
    import uvicorn

    port = int(os.environ.get("RNID_PORT", "8765"))
    if not 1 <= port <= 65535:
        raise ValueError("RNID_PORT must be between 1 and 65535")
    config = ServiceConfig.from_env()
    shutdown_timeout = math.ceil(config.upload_timeout + config.process_timeout + config.download_timeout + 30)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    uvicorn.run(
        create_app(config), host="127.0.0.1", port=port, workers=1, http="h11", ws="none",
        access_log=False, proxy_headers=False, timeout_graceful_shutdown=shutdown_timeout,
    )


if __name__ == "__main__":
    main()
