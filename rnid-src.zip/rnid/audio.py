"""Bounded canonical audio decoding and paired WAV export."""

from __future__ import annotations

import json
import math
import os
import re
import stat
import subprocess
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path

import numpy as np

from .errors import RNIDError

SAMPLE_RATE = 44_100
CHANNELS = 2
PEAK_CEILING_DBTP = -1.0
# The ebur128 summary rounds to 0.1 dB. Leave space for its rounding and PCM quantization.
METER_MARGIN_DB = 0.06
_TRUE_PEAK = re.compile(rb"True peak:\s+Peak:\s+(-?inf|[-+]?\d+(?:\.\d+)?)\s+dBFS")
_INPUT_FORMATS = "wav,flac,mp3,mov,mp4,m4a,3gp,3g2,mj2"
_INPUT_CODECS = {"flac": "flac", "mp3": "mp3", "mov": "aac"}
_RAW_STEREO = ["-f", "f64le", "-ar", str(SAMPLE_RATE), "-ac", str(CHANNELS), "-i", "pipe:0"]
# The MP3 decoder logs this once when the final frame is incomplete. Many published MP3s
# end that way (two of the four licensed fixtures). FFmpeg still exits 0 and decodes every
# complete frame, identically to a tolerant decode, so only the last ~26 ms are lost. A
# file cut off mid-frame looks the same and is accepted as a shorter clip, as files cut at
# a frame boundary already were. Any other decoder error, or a repeat, rejects the file.
_BENIGN_DECODER_ERROR = re.compile(rb"^\[mp3(?:float)? @ 0x[0-9a-f]+\] \[error\] invalid new backstep -1$")


def _has_decoder_error(stderr: bytes) -> bool:
    errors = [line.strip() for line in stderr.splitlines() if b"[error]" in line]
    benign = [line for line in errors if _BENIGN_DECODER_ERROR.match(line)]
    return len(errors) > len(benign) or len(benign) > 1


@dataclass(frozen=True)
class AudioLimits:
    # Rendering costs about 20 s and 0.31 GiB per minute of audio on ulws141 (one BLAS
    # thread): 15 minutes takes about 5 minutes and 4.7 GiB, inside the private service's
    # 360 s deadline. Raise RNID_MAX_SECONDS for longer files on a host with the memory.
    # The byte cap admits a 15-minute 32-bit float stereo WAV (about 318 MB).
    min_seconds: float = 1
    max_seconds: float = 15 * 60
    max_bytes: int = 400 * 1024**2

    def __post_init__(self) -> None:
        if (
            not 0 < self.min_seconds <= self.max_seconds < math.inf
            or self.min_frames > self.max_frames or self.max_frames >= 2**63 - 1
            or self.max_bytes < 1
        ):
            raise ValueError("Audio limits must allow a positive duration and file size.")

    @property
    def min_frames(self) -> int:
        return math.ceil(Decimal(str(self.min_seconds)) * SAMPLE_RATE)

    @property
    def max_frames(self) -> int:
        return math.floor(Decimal(str(self.max_seconds)) * SAMPLE_RATE)


def _run(
    binary: str, args: list[str], *, payload: bytes | None = None, timeout: float = 60
) -> subprocess.CompletedProcess[bytes]:
    executable = os.environ.get(f"RNID_{binary.upper()}") or binary
    try:
        return subprocess.run(
            [executable, *args], input=payload, capture_output=True, timeout=timeout, check=False
        )
    except OSError as exc:
        raise RNIDError("FFMPEG_UNAVAILABLE", f"{binary} could not be started.") from exc
    except subprocess.TimeoutExpired as exc:
        raise RNIDError("PROCESSING_TIMEOUT", f"{binary} exceeded its processing deadline.") from exc


def ffmpeg_version() -> str:
    versions = []
    for binary in ("ffmpeg", "ffprobe"):
        result = _run(binary, ["-version"], timeout=5)
        if result.returncode or not result.stdout:
            raise RNIDError("FFMPEG_UNAVAILABLE", f"{binary} version could not be read.")
        versions.append(result.stdout.decode("utf-8", errors="replace").splitlines()[0])
    return versions[0]


def _probe(path: Path, *, export: bool = False) -> dict:
    result = _run(
        "ffprobe",
        [
            "-v", "error", "-max_alloc", "134217728", "-protocol_whitelist", "file",
            "-format_whitelist", _INPUT_FORMATS, "-show_entries",
            "format=format_name,duration:stream=index,codec_name,codec_type,channels,"
            "channel_layout,duration,duration_ts,time_base,sample_rate,bits_per_sample:"
            "stream_disposition=attached_pic", "-of", "json", str(path.absolute()),
        ],
        timeout=10,
    )
    if result.returncode or result.stderr:
        if not export and b"not on whitelist" in result.stderr:
            raise RNIDError("UNSUPPORTED_FORMAT", "Only WAV, FLAC, MP3 and AAC in M4A are supported.")
        code = "EXPORT_FAILED" if export else "INVALID_AUDIO"
        raise RNIDError(code, "Audio container could not be read.")
    return json.loads(result.stdout)


def _validate_input(metadata: dict, limits: AudioLimits) -> tuple[int, int]:
    container = metadata.get("format", {})
    format_name = container.get("format_name", "").split(",")[0]
    streams = metadata.get("streams", [])
    audio = [stream for stream in streams if stream.get("codec_type") == "audio"]
    has_video = any(
        stream.get("codec_type") == "video" and not stream.get("disposition", {}).get("attached_pic")
        for stream in streams
    )
    if has_video or format_name not in {"wav", *_INPUT_CODECS}:
        raise RNIDError("UNSUPPORTED_FORMAT", "Provide an audio-only WAV, FLAC, MP3 or AAC in M4A.")
    if len(audio) != 1:
        raise RNIDError("INVALID_AUDIO", "The input must contain exactly one audio stream.")
    stream = audio[0]
    if format_name != "wav" and stream.get("codec_name") != _INPUT_CODECS[format_name]:
        raise RNIDError("UNSUPPORTED_FORMAT", "The audio codec is unsupported in this container.")
    channels = stream.get("channels")
    layout = stream.get("channel_layout", "unknown")
    if channels not in (1, 2) or layout not in ("unknown", "mono" if channels == 1 else "stereo"):
        raise RNIDError("UNSUPPORTED_FORMAT", "Only mono and left/right stereo audio are supported.")

    # Compressed containers can report padding that decoding removes. The canonical frame
    # check below enforces the exact limits for every format.
    padding = 0.25 if format_name in {"mp3", "mov"} else 0
    for duration in (stream.get("duration"), container.get("duration")):
        if duration in (None, "N/A"):
            continue
        try:
            seconds = float(duration)
        except (TypeError, ValueError) as exc:
            raise RNIDError("INVALID_AUDIO", "Audio duration metadata is invalid.") from exc
        if not math.isfinite(seconds) or seconds < 0:
            raise RNIDError("INVALID_AUDIO", "Audio duration metadata is invalid.")
        # FFprobe prints container duration to six decimal places.
        if seconds > limits.max_seconds + padding + 0.000001:
            raise _duration_error(limits)
    return stream["index"], channels


def _duration_error(limits: AudioLimits) -> RNIDError:
    return RNIDError(
        "DURATION_OUT_OF_RANGE",
        f"Decoded duration must be between {limits.min_seconds:g} and {limits.max_seconds:g} seconds.",
    )


def decode(path: Path | str, limits: AudioLimits = AudioLimits()) -> np.ndarray:
    """Return canonical float32 stereo frames, with mono duplicated explicitly."""
    path = Path(path)
    try:
        info = path.stat()
    except OSError as exc:
        raise RNIDError("INVALID_AUDIO", "The input file could not be read.") from exc
    if not stat.S_ISREG(info.st_mode) or info.st_size == 0:
        raise RNIDError("INVALID_AUDIO", "The input must be a nonempty regular file.")
    if info.st_size > limits.max_bytes:
        raise RNIDError("INPUT_TOO_LARGE", f"The input exceeds {limits.max_bytes} bytes.")

    stream_index, channels = _validate_input(_probe(path), limits)
    max_frames = limits.max_frames
    result = _run(
        "ffmpeg",
        [
            "-hide_banner", "-nostdin", "-v", "level+warning", "-xerror", "-max_alloc", "134217728",
            "-threads", "1", "-filter_threads", "1", "-err_detect", "crccheck+explode",
            "-protocol_whitelist", "file", "-format_whitelist", _INPUT_FORMATS,
            "-i", str(path.absolute()), "-map", f"0:{stream_index}", "-map_metadata", "-1",
            "-af", f"aresample={SAMPLE_RATE}:async=0,atrim=end_sample={max_frames + 1}",
            "-c:a", "pcm_f32le", "-f", "f32le", "pipe:1",
        ],
    )
    frame_bytes = channels * 4
    if (
        result.returncode or _has_decoder_error(result.stderr)
        or b"filesize and duration do not match" in result.stderr
        or len(result.stdout) % frame_bytes or not result.stdout
    ):
        raise RNIDError("INVALID_AUDIO", "The audio stream could not be decoded completely.")
    frames = len(result.stdout) // frame_bytes
    if not limits.min_frames <= frames <= max_frames:
        raise _duration_error(limits)
    pcm = np.frombuffer(result.stdout, dtype="<f4").reshape(frames, channels)
    if not np.isfinite(pcm).all():
        raise RNIDError("INVALID_AUDIO", "The decoded audio contains non-finite samples.")
    return pcm if channels == CHANNELS else np.repeat(pcm, CHANNELS, axis=1)


def _raw(samples: np.ndarray) -> bytes:
    return np.asarray(samples, dtype="<f8").tobytes()


def _true_peak(*, samples: np.ndarray | None = None, path: Path | None = None) -> float | None:
    source_args = _RAW_STEREO if path is None else ["-i", str(path.absolute())]
    result = _run(
        "ffmpeg",
        [
            "-hide_banner", "-nostdin", "-nostats", "-v", "info", "-xerror",
            "-threads", "1", "-filter_threads", "1", *source_args,
            # Include the interpolated tail after the last actual sample in the measurement.
            "-af", "apad=pad_len=441,ebur128=peak=true:framelog=verbose", "-f", "null", "-",
        ],
        payload=None if samples is None else _raw(samples),
    )
    match = _TRUE_PEAK.search(result.stderr)
    if result.returncode or match is None:
        raise RNIDError("EXPORT_FAILED", "FFmpeg could not measure true peak.")
    peak = float(match[1])
    if peak == -math.inf:
        return None
    if not math.isfinite(peak):
        raise RNIDError("EXPORT_FAILED", "The true peak measurement is non-finite.")
    return peak


def _encode_wav(samples: np.ndarray, path: Path) -> float | None:
    result = _run(
        "ffmpeg",
        [
            "-hide_banner", "-nostdin", "-v", "error", "-n", "-xerror", *_RAW_STEREO,
            "-map", "0:a:0", "-map_metadata", "-1", "-map_chapters", "-1", "-fflags", "+bitexact",
            "-flags:a", "+bitexact", "-c:a", "pcm_s24le", "-f", "wav", str(path.absolute()),
        ],
        payload=_raw(samples),
    )
    if result.returncode or result.stderr:
        raise RNIDError("EXPORT_FAILED", "FFmpeg could not write the PCM WAV.")
    streams = _probe(path, export=True).get("streams", [])
    if len(streams) != 1 or any(
        streams[0].get(key) != value
        for key, value in {
            "codec_name": "pcm_s24le", "channels": CHANNELS, "sample_rate": str(SAMPLE_RATE),
            "bits_per_sample": 24, "duration_ts": len(samples), "time_base": f"1/{SAMPLE_RATE}",
        }.items()
    ):
        raise RNIDError("EXPORT_FAILED", "The WAV export does not match the expected audio format and length.")
    return _true_peak(path=path)


def export_pair(reference: np.ndarray, simulated: np.ndarray, directory: Path | str) -> dict:
    """Write and verify a pair inside a caller-owned staging directory."""
    directory = Path(directory)
    if (
        reference.ndim != 2 or reference.shape[1] != CHANNELS or not len(reference)
        or reference.shape != simulated.shape
        or not np.isfinite(reference).all() or not np.isfinite(simulated).all()
    ):
        raise RNIDError("EXPORT_FAILED", "The render branches do not contain matching finite stereo frames.")
    branches = {"reference": reference, "simulated": simulated}
    input_peaks = {name: _true_peak(samples=samples) for name, samples in branches.items()}
    louder = max((peak for peak in input_peaks.values() if peak is not None), default=-math.inf)
    gain_db = 0.0 if louder < PEAK_CEILING_DBTP else PEAK_CEILING_DBTP - METER_MARGIN_DB - louder
    gain = 10 ** (gain_db / 20)
    output_peaks = {
        name: _encode_wav(
            np.multiply(samples, gain, dtype=np.float64) if gain_db else samples,
            directory / f"{name}.wav",
        )
        for name, samples in branches.items()
    }
    if any(peak is not None and peak > PEAK_CEILING_DBTP for peak in output_peaks.values()):
        raise RNIDError("EXPORT_FAILED", "An exported WAV exceeded the common true-peak ceiling.")
    return {
        "true_peak_ceiling_dbtp": PEAK_CEILING_DBTP,
        "true_peak_meter": "ffmpeg ebur128",
        "pre_gain_true_peak_dbtp": input_peaks,
        "export_true_peak_dbtp": output_peaks,
        "common_gain_db": gain_db,
        "common_gain_linear": gain,
    }
