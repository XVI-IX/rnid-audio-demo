"""Suggest sustained musical transitions on the canonical source timeline."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import math

import numpy as np
from scipy.fft import rfft, rfftfreq
from scipy.ndimage import maximum_filter1d
from scipy.signal import resample_poly
from scipy.signal.windows import hann

from .audio import CHANNELS, SAMPLE_RATE

DETECTOR_VERSION = "1.1.0"
ANALYSIS_RATE = SAMPLE_RATE // 2
WINDOW_LENGTH = 2048
HOP_LENGTH = 256
CONTEXT_FRAMES = math.ceil(2 * ANALYSIS_RATE / HOP_LENGTH)
MIN_GAP_SAMPLES = 5 * SAMPLE_RATE
LOCAL_RADIUS = round(0.25 * ANALYSIS_RATE / HOP_LENGTH)
NEARBY_CONTEXT = round(0.35 * ANALYSIS_RATE / HOP_LENGTH)
MEL_BANDS = 32
FRAME_BATCH = 256
MIN_POWER = 1e-10
# Broadband RMS, low-end (40-200 Hz), high-band presence (2.3-10.8 kHz), and mel spectral change.
WEIGHTS = np.array([0.34, 0.22, 0.16, 0.28])


@dataclass(frozen=True)
class DetectorSettings:
    """Thresholds for the versioned transition score."""

    inactivity_dbfs: float = -55.0
    min_rms_increase_db: float = 3.5
    min_bass_increase_db: float = 5.0
    min_high_increase_db: float = 4.2
    min_spectral_distance: float = 0.16
    scale_floors: tuple[float, float, float] = (2.0, 3.0, 0.06)
    high_scale_floor: float = 2.5
    min_score: float = 1.05
    snap_window_seconds: float = 0.25

    def __post_init__(self) -> None:
        positive = (
            self.min_rms_increase_db,
            self.min_bass_increase_db,
            self.min_high_increase_db,
            self.high_scale_floor,
            self.min_score,
            *self.scale_floors,
        )
        if (
            not math.isfinite(self.inactivity_dbfs)
            or not all(math.isfinite(value) and value > 0 for value in positive)
            or not 0 < self.min_spectral_distance <= 1
            or not (math.isfinite(self.snap_window_seconds) and 0 <= self.snap_window_seconds <= 0.5)
            or len(self.scale_floors) != 3
        ):
            raise ValueError("Invalid climax detector settings.")


@lru_cache(maxsize=1)
def _spectral_filters() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    frequencies = rfftfreq(WINDOW_LENGTH, 1 / ANALYSIS_RATE)
    mel_edges = np.linspace(
        2595 * np.log10(1 + 25 / 700),
        2595 * np.log10(1 + 10_800 / 700),
        MEL_BANDS + 2,
    )
    hz_edges = 700 * (10 ** (mel_edges / 2595) - 1)
    lower, center, upper = hz_edges[:-2, None], hz_edges[1:-1, None], hz_edges[2:, None]
    falling = (upper - frequencies) / (upper - center)
    rising = (frequencies - lower) / (center - lower)
    mel_weights = np.maximum(np.minimum(rising, falling), 0)
    bass_bins = (frequencies >= 40) & (frequencies <= 200)
    high_bins = (frequencies >= 2_300) & (frequencies <= 10_800)
    return hann(WINDOW_LENGTH, sym=False), bass_bins, high_bins, mel_weights


def _decibels(power: np.ndarray) -> np.ndarray:
    return 10 * np.log10(np.maximum(power, MIN_POWER))


def _features(samples: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    downsampled = resample_poly(samples.astype(np.float64, copy=False), 1, 2, axis=0)
    total_windows = (len(downsampled) - WINDOW_LENGTH) // HOP_LENGTH + 1
    window, bass_bins, high_bins, mel_weights = _spectral_filters()
    energy_scale = 2 / (WINDOW_LENGTH * np.square(window).sum())
    result = np.empty((total_windows, MEL_BANDS + 3))
    log_mel_frames = np.empty((total_windows, MEL_BANDS))
    for start in range(0, total_windows, FRAME_BATCH):
        count = min(FRAME_BATCH, total_windows - start)
        chunk_start = start * HOP_LENGTH
        chunk_end = chunk_start + (count - 1) * HOP_LENGTH + WINDOW_LENGTH
        chunk = downsampled[chunk_start:chunk_end]
        windows = np.lib.stride_tricks.sliding_window_view(chunk, WINDOW_LENGTH, axis=0)[::HOP_LENGTH]
        frames = windows * window
        spectrum = rfft(frames, axis=-1)
        # Pool the two power spectra after transformation so reversed stereo polarity cannot cancel.
        power = np.square(np.abs(spectrum)).mean(axis=1) * energy_scale
        power[:, [0, -1]] *= 0.5
        rms = power.sum(axis=1)
        bass = power[:, bass_bins].sum(axis=1)
        high = power[:, high_bins].sum(axis=1)
        mel_power = power @ mel_weights.T
        log_mel_frames[start:start + count] = _decibels(mel_power)
        mel_sum = mel_power.sum(axis=1, keepdims=True)
        mel = np.divide(mel_power, mel_sum, out=np.zeros_like(mel_power), where=mel_sum > MIN_POWER)
        result[start:start + count] = np.column_stack(
            (_decibels(rms), _decibels(bass), _decibels(high), mel)
        )
    # Half-wave rectified spectral flux in dB across mel bands for local onset snapping.
    flux = np.zeros(total_windows)
    if total_windows > 1:
        flux[1:] = np.maximum(0.0, np.diff(log_mel_frames, axis=0)).mean(axis=1)
    return result, flux


def _averages(prefix: np.ndarray, starts: np.ndarray, length: int) -> np.ndarray:
    return (prefix[starts + length] - prefix[starts]) / length


def _changes(before: np.ndarray, after: np.ndarray) -> np.ndarray:
    pre_mel, post_mel = before[:, 3:], after[:, 3:]
    pre_norm = np.linalg.norm(pre_mel, axis=1)
    post_norm = np.linalg.norm(post_mel, axis=1)
    norm_product = pre_norm * post_norm
    dot = np.sum(pre_mel * post_mel, axis=1)
    # Two inactive contexts have no spectral change. One inactive context has no matching shape.
    cosine = np.divide(dot, norm_product, out=(pre_norm + post_norm == 0).astype(float), where=norm_product > 0)
    return np.column_stack((after[:, :3] - before[:, :3], np.clip(1 - cosine, 0, 1)))


def _absolute_gate(changes: np.ndarray, settings: DetectorSettings, fraction: float = 1.0) -> np.ndarray:
    rms, bass, high, spectral = changes.T
    return (
        (rms >= fraction * settings.min_rms_increase_db)
        | ((rms >= -2.0) & (
            (bass >= fraction * settings.min_bass_increase_db)
            | (high >= fraction * settings.min_high_increase_db)
            | (spectral >= fraction * settings.min_spectral_distance)
        ))
    )


def _sustained(
    prefix: np.ndarray, centers: np.ndarray, before: np.ndarray, settings: DetectorSettings
) -> np.ndarray:
    # Require audible evidence in at least three of the four post-transition half-second blocks.
    boundaries = np.round(np.linspace(0, CONTEXT_FRAMES, 5)).astype(int)
    supporting_blocks = np.zeros(len(centers), dtype=int)
    for start, end in zip(boundaries, boundaries[1:]):
        after = _averages(prefix, centers + start, end - start)
        changes = _changes(before, after)
        supporting_blocks += (after[:, 0] >= settings.inactivity_dbfs) & _absolute_gate(changes, settings, 0.65)
    return supporting_blocks >= 3


def _snap_center(center: int, flux: np.ndarray, min_center: int, max_center: int, radius: int) -> int:
    """Snap a broad transition peak to a prominent onset attack within +/-250 ms when present."""
    if radius <= 0:
        return center
    lo = max(min_center, center - radius)
    hi = min(max_center, center + radius)
    region = flux[lo:hi + 1]
    if not len(region):
        return center
    median_flux = float(np.median(flux[min_center:max_center + 1]))
    mad_flux = float(np.median(np.abs(flux[min_center:max_center + 1] - median_flux)))
    prominence_gate = median_flux + max(0.35, 3.0 * 1.4826 * mad_flux)
    best_offset = int(np.argmax(region))
    best_flux = float(region[best_offset])
    if best_flux >= prominence_gate and best_flux >= 1.25 * float(flux[center]):
        return lo + best_offset
    return center


def _rank(features: np.ndarray, flux: np.ndarray, settings: DetectorSettings) -> list[dict]:
    prefix = np.vstack((np.zeros(features.shape[1]), np.cumsum(features, axis=0)))
    centers = np.arange(CONTEXT_FRAMES, len(features) - CONTEXT_FRAMES + 1)
    before = _averages(prefix, centers - CONTEXT_FRAMES, CONTEXT_FRAMES)
    after = _averages(prefix, centers, CONTEXT_FRAMES)
    changes = _changes(before, after)
    floors = (
        settings.scale_floors[0],
        settings.scale_floors[1],
        settings.high_scale_floor,
        settings.scale_floors[2],
    )
    median = np.median(changes, axis=0)
    deviation = np.median(np.abs(changes - median), axis=0)
    scale = np.maximum(1.4826 * deviation, floors)
    standardized = np.maximum(0, (changes - median) / scale)
    scores = np.round(standardized @ WEIGHTS, 6)
    # The long comparison can span a change even after it ended. Require local evidence
    # so the nearest eligible frame cannot mislabel a start or finish outside the context.
    nearby = _changes(
        _averages(prefix, centers - NEARBY_CONTEXT, NEARBY_CONTEXT),
        _averages(prefix, centers, NEARBY_CONTEXT),
    )
    allowed = (
        (after[:, 0] >= settings.inactivity_dbfs)
        & _absolute_gate(changes, settings)
        & _absolute_gate(nearby, settings, 0.30)
        & _sustained(prefix, centers, before, settings)
        & (scores >= settings.min_score)
    )
    scores[~allowed] = -np.inf
    is_local_peak = scores == maximum_filter1d(scores, 2 * LOCAL_RADIUS + 1, mode="constant", cval=-np.inf)
    ranking = sorted(np.flatnonzero(allowed & is_local_peak), key=lambda index: (-scores[index], index))
    snap_radius = round(settings.snap_window_seconds * ANALYSIS_RATE / HOP_LENGTH)
    min_center, max_center = int(centers[0]), int(centers[-1])
    candidates = []
    for index in ranking:
        snapped_center = _snap_center(int(centers[index]), flux, min_center, max_center, snap_radius)
        # The analysis clock starts at source frame zero and runs at half the source sample rate.
        sample = 2 * (snapped_center * HOP_LENGTH + WINDOW_LENGTH // 2)
        if all(abs(sample - candidate["sample"]) >= MIN_GAP_SAMPLES for candidate in candidates):
            candidates.append({"sample": sample, "seconds": sample / SAMPLE_RATE, "score": float(scores[index])})
        if len(candidates) == 3:
            break
    candidates.sort(key=lambda item: (-item["score"], item["sample"]))
    return candidates


def detect(samples: np.ndarray, settings: DetectorSettings = DetectorSettings()) -> dict:
    """Return up to three ranked sustained transitions in finite 44.1 kHz stereo PCM."""
    if samples.ndim != 2 or samples.shape[1] != CHANNELS or not np.isfinite(samples).all():
        raise ValueError("Climax detection requires finite stereo PCM.")
    # Account for the analysis window as well as the full context on each side.
    min_frames = 2 * (WINDOW_LENGTH + (2 * CONTEXT_FRAMES - 1) * HOP_LENGTH) - 1
    if len(samples) >= min_frames:
        features, flux = _features(samples)
        candidates = _rank(features, flux, settings)
    else:
        candidates = []
    selected = candidates[0] if candidates else None
    return {
        "status": "ok" if selected else "no_candidate",
        "selected_by": "automatic" if selected else None,
        "selected_sample": selected["sample"] if selected else None,
        "selected_seconds": selected["seconds"] if selected else None,
        "candidates": candidates,
        "detector_version": DETECTOR_VERSION,
    }
