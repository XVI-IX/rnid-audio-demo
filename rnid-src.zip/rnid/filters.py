"""Approximate each ear's MSBG effect as a downloadable minimum-phase impulse response.

MSBG is level-dependent and smears detail over time, so no fixed filter reproduces it. The
impulse response matches the average tonal change MSBG applies to steady pink noise at a
given input level. Under level convention v2, on 20-second excerpts of four licensed songs
at their own levels with five profiles, it was within 1.2 dB of the real render on average
per octave band from 63 Hz to 8 kHz (90 % within 2.9 dB, worst 8.3 dB). From 8 to 16 kHz the
dB error can be large (up to 50 dB), but only where that band is already 60 dB or more
below the clip in both versions, so it is inaudible.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from functools import lru_cache
import math
from pathlib import Path

import numpy as np
from scipy.signal import welch

from . import audio, msbg
from .errors import RNIDError

METHOD = "pink_probe_min_phase_v1"
FILE_NAME = "filter-ir.wav"
TAPS = 8192
DEFAULT_LEVEL_DBFS = -20.0
LEVEL_STEP_DB = 0.5
PROBE_SECONDS = 8
PROBE_SEED = 0
SMOOTHING_OCTAVE_FRACTION = 6
FLOOR_DB = -100.0
WELCH_SEGMENT = 8192
_NFFT = 1 << 15
TABLE_FREQUENCIES_HZ = (
    25, 31.5, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400, 500, 630, 800, 1000, 1250,
    1600, 2000, 2500, 3150, 4000, 5000, 6300, 8000, 10000, 12500, 16000,
)
NOTE = (
    "Approximates the average tonal change of this hearing profile at the stated input level. "
    "It omits the loudness-dependent and time-smearing parts of the model. Above 8 kHz the "
    "match is unreliable. Apply the left channel to the left ear and the right channel to the "
    "right ear, at unity gain, with any IR normalisation turned off."
)


def round_level(level_dbfs: float) -> float:
    return round(level_dbfs / LEVEL_STEP_DB) * LEVEL_STEP_DB


@lru_cache(maxsize=1)
def _unit_pink_probe() -> np.ndarray:
    frames = PROBE_SECONDS * audio.SAMPLE_RATE
    spectrum = np.fft.rfft(np.random.default_rng(PROBE_SEED).standard_normal(frames))
    frequencies = np.fft.rfftfreq(frames, 1 / audio.SAMPLE_RATE)
    spectrum[0] = 0
    spectrum[1:] /= np.sqrt(frequencies[1:])
    probe = np.fft.irfft(spectrum, frames)
    return probe / math.sqrt(float(np.mean(probe**2)))


def _smoothed_gain_db(source: np.ndarray, processed: np.ndarray) -> np.ndarray:
    frequencies, source_power = welch(source, audio.SAMPLE_RATE, nperseg=WELCH_SEGMENT)
    _, processed_power = welch(processed, audio.SAMPLE_RATE, nperseg=WELCH_SEGMENT)
    gain = 10 * np.log10(np.maximum(processed_power, 1e-30) / np.maximum(source_power, 1e-30))
    grid = np.fft.rfftfreq(_NFFT, 1 / audio.SAMPLE_RATE)
    half_band = 2 ** (0.5 / SMOOTHING_OCTAVE_FRACTION)
    smoothed = np.empty_like(grid)
    for index, frequency in enumerate(grid):
        centre = max(frequency, 20.0)
        band = (frequencies >= centre / half_band) & (frequencies <= centre * half_band)
        smoothed[index] = (
            10 * np.log10(np.mean(10 ** (gain[band] / 10))) if band.any()
            else np.interp(centre, frequencies, gain)
        )
    return np.maximum(smoothed, FLOOR_DB)


def _minimum_phase(gain_db: np.ndarray) -> np.ndarray:
    """Homomorphic minimum-phase FIR for a magnitude response, tapered to TAPS."""
    cepstrum = np.fft.irfft(gain_db * (math.log(10) / 20), _NFFT)
    folded = np.zeros(_NFFT)
    folded[0] = cepstrum[0]
    folded[1:_NFFT // 2] = 2 * cepstrum[1:_NFFT // 2]
    folded[_NFFT // 2] = cepstrum[_NFFT // 2]
    response = np.fft.irfft(np.exp(np.fft.rfft(folded)), _NFFT)[:TAPS]
    fade = TAPS // 8
    response[-fade:] *= 0.5 * (1 + np.cos(np.linspace(0, math.pi, fade)))
    return response


@lru_cache(maxsize=32)
def _design(left: tuple, right: tuple, model: tuple, levels: tuple[float, float]):
    unit = _unit_pink_probe()
    probe = np.column_stack([unit * 10 ** (level / 20) for level in levels])
    ears = (
        {"frequencies_hz": left[0], "thresholds_db_hl": left[1]},
        {"frequencies_hz": right[0], "thresholds_db_hl": right[1]},
    )
    processed, _ = msbg.render(probe, *ears, dict(model))
    gains = [_smoothed_gain_db(probe[:, ear], processed[:, ear]) for ear in (0, 1)]
    response = np.column_stack([_minimum_phase(gain) for gain in gains])
    if not np.isfinite(response).all() or np.abs(response).max() >= 1:
        raise RNIDError("MODEL_ERROR", "The hearing filter could not be represented as a WAV impulse response.")
    grid = np.fft.rfftfreq(_NFFT, 1 / audio.SAMPLE_RATE)
    table = [
        {"frequency_hz": frequency, **{
            side: round(float(np.interp(frequency, grid, gain)), 2)
            for side, gain in zip(("left_db", "right_db"), gains)
        }}
        for frequency in TABLE_FREQUENCIES_HZ
    ]
    response.setflags(write=False)
    return response, tuple(table)


def design(
    left: Mapping[str, Sequence[float]],
    right: Mapping[str, Sequence[float]],
    model_settings: Mapping[str, str | float],
    levels_dbfs: Mapping[str, float],
) -> tuple[np.ndarray, dict]:
    """Return a [TAPS, 2] impulse response and its description for the given ear input levels."""
    levels = (round_level(levels_dbfs["left"]), round_level(levels_dbfs["right"]))
    response, table = _design(
        (tuple(left["frequencies_hz"]), tuple(left["thresholds_db_hl"])),
        (tuple(right["frequencies_hz"]), tuple(right["thresholds_db_hl"])),
        tuple(sorted((key, model_settings[key]) for key in ("src_pos", "equiv_0db_spl", "ahr"))),
        levels,
    )
    return response, {
        "method": METHOD,
        "taps": TAPS,
        "sample_rate_hz": audio.SAMPLE_RATE,
        "channels": {"left": "left ear", "right": "right ear"},
        "phase": "minimum",
        "probe": {"signal": "pink noise", "seconds": PROBE_SECONDS, "seed": PROBE_SEED},
        "probe_level_dbfs": {"left": levels[0], "right": levels[1]},
        "smoothing": f"1/{SMOOTHING_OCTAVE_FRACTION} octave",
        "gain_table": [dict(row) for row in table],
        "note": NOTE,
    }


def bundle_levels(input_rms_dbfs: Mapping[str, float | None], bypassed: Mapping[str, bool]) -> dict:
    """Probe each ear at the clip's own level; a silent ear borrows the other ear's level."""
    audible = {side: input_rms_dbfs[side] for side in ("left", "right") if not bypassed[side]}
    fallback = next(iter(audible.values()), DEFAULT_LEVEL_DBFS)
    return {side: audible.get(side, fallback) for side in ("left", "right")}


def write(path: Path, response: np.ndarray) -> None:
    """Write a 44.1 kHz stereo 24-bit PCM WAV, verified like the render exports."""
    audio._encode_wav(response, path)


# Browser preview set: filters at fixed levels, blended per ear for the clip's own level.
# Mixing the two nearest 5 dB designs stayed within 0.31 dB per octave (63 Hz-8 kHz) of a
# filter designed at the midpoint, against up to 2.45 dB for the nearest design alone.
BROWSER_INDEX = "index.json"
BROWSER_LEVELS_DBFS = (-40.0, -35.0, -30.0, -25.0, -20.0, -15.0, -10.0, -5.0)
BROWSER_SILENT_DBFS = -100.0
BROWSER_SCHEMA_VERSION = "1.0"


def browser_file(profile_id: str, level_dbfs: float) -> str:
    if level_dbfs >= 0 or level_dbfs != int(level_dbfs):
        raise ValueError("Browser filter levels must be negative whole dBFS values")
    return f"{profile_id}/ir_m{abs(int(level_dbfs))}dbfs.wav"


def blend_weights(level_dbfs: float, levels: Sequence[float] = BROWSER_LEVELS_DBFS) -> dict:
    """Reference for the browser module: the two nearest design levels and the upper weight.

    The response for one ear is (1 - weight) * lower + weight * upper, with the level
    clamped to the designed range.
    """
    level = min(max(level_dbfs, levels[0]), levels[-1])
    for lower, upper in zip(levels, levels[1:]):
        if level <= upper:
            return {"lower": lower, "upper": upper, "weight": (level - lower) / (upper - lower)}
    return {"lower": levels[-1], "upper": levels[-1], "weight": 0.0}


def blended_response(
    responses: Mapping[float, np.ndarray], levels_dbfs: Mapping[str, float]
) -> np.ndarray:
    """Python equivalent of the browser module's per-ear blend, for checks and offline use."""
    channels = []
    for ear, side in enumerate(("left", "right")):
        blend = blend_weights(levels_dbfs[side], tuple(sorted(responses)))
        channels.append(
            (1 - blend["weight"]) * responses[blend["lower"]][:, ear]
            + blend["weight"] * responses[blend["upper"]][:, ear]
        )
    return np.column_stack(channels)


def write_browser_set(profiles: Mapping, out_dir: Path, levels: Sequence[float] = BROWSER_LEVELS_DBFS) -> dict:
    """Write `<profile>/ir_mNNdbfs.wav` for every level plus `index.json`, all or nothing."""
    import json
    import tempfile

    out_dir = Path(out_dir).absolute()
    if out_dir.is_symlink() or (out_dir.exists() and (not out_dir.is_dir() or any(out_dir.iterdir()))):
        raise RNIDError("OUTPUT_EXISTS", "The output path must be absent or an empty directory.")
    levels = tuple(sorted(float(level) for level in levels))
    if len(levels) < 2 or len(set(levels)) != len(levels):
        raise RNIDError("INVALID_ARGUMENTS", "A browser filter set needs at least two distinct levels.")
    entries = []
    try:
        out_dir.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix=".rnid-browser-filters-", dir=out_dir.parent) as staging:
            root = Path(staging) / "set"
            root.mkdir()
            for profile_id, profile in profiles.items():
                (root / profile_id).mkdir()
                files = {}
                for level in levels:
                    response, _ = design(profile.left, profile.right, profile.model, {"left": level, "right": level})
                    name = browser_file(profile_id, level)
                    write(root / name, response)
                    files[f"{level:g}"] = name
                entries.append({
                    **profile.public(), "digest": f"sha256:{profile.digest}", "files": files,
                })
            index = {
                "schema_version": BROWSER_SCHEMA_VERSION,
                "method": METHOD,
                "sample_rate_hz": audio.SAMPLE_RATE,
                "taps": TAPS,
                "channels": ["left ear", "right ear"],
                "levels_dbfs": list(levels),
                "silent_below_dbfs": BROWSER_SILENT_DBFS,
                "blend": (
                    "Per ear, measure the clip channel's RMS in dBFS (a silent channel uses the other "
                    "channel's level), clamp it to levels_dbfs, and mix the two nearest designs linearly."
                ),
                "playback": "Convolve with normalisation off, unity gain, and keep the clip's length.",
                "note": NOTE,
                "profiles": entries,
            }
            (root / BROWSER_INDEX).write_text(json.dumps(index, indent=2, allow_nan=False) + "\n", encoding="utf-8")
            if out_dir.exists():  # an existing empty directory
                for item in root.iterdir():
                    item.rename(out_dir / item.name)
            else:
                root.rename(out_dir)
    except OSError as error:
        raise RNIDError("EXPORT_FAILED", "The browser filter set could not be saved.") from error
    return index


def main(argv: Sequence[str] | None = None) -> int:
    import argparse
    import json
    import sys

    from .profiles import load_registry

    parser = argparse.ArgumentParser(prog="python -m rnid.filters")
    commands = parser.add_subparsers(dest="command", required=True)
    browser = commands.add_parser("browser-set", help="Write the level-indexed filter set for the browser preview")
    browser.add_argument("--out-dir", required=True, type=Path)
    browser.add_argument("--profile", action="append", dest="profiles")
    args = parser.parse_args(argv)
    try:
        registry = load_registry()
        ids = list(dict.fromkeys(args.profiles)) if args.profiles else list(registry)
        missing = [profile_id for profile_id in ids if profile_id not in registry]
        if missing:
            raise RNIDError("INVALID_PROFILE", f"Unavailable profile: {missing[0]}.")
        write_browser_set({profile_id: registry[profile_id] for profile_id in ids}, args.out_dir)
        print(args.out_dir / BROWSER_INDEX)
        return 0
    except RNIDError as error:
        print(json.dumps({"error": {"code": error.code, "message": error.message}}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
