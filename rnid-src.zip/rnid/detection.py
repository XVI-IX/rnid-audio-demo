"""Bound the detector runtime independently of the audio render."""

import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile

import numpy as np

from .errors import RNIDError


def analyse(samples: np.ndarray) -> dict:
    try:
        timeout = float(os.environ.get("RNID_DETECT_TIMEOUT_SECONDS", "12"))
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError
    except ValueError as error:
        raise RNIDError("DETECTOR_ERROR", "Invalid detector deadline.") from error

    try:
        with tempfile.TemporaryDirectory(prefix="rnid-detect-") as workspace:
            path = Path(workspace) / "canonical.npy"
            np.save(path, samples, allow_pickle=False)
            result = subprocess.run(
                [sys.executable, "-m", "rnid.detection", str(path)],
                stdin=subprocess.DEVNULL,
                capture_output=True,
                timeout=timeout,
                check=True,
            )
        return json.loads(result.stdout)
    except subprocess.TimeoutExpired as error:
        raise RNIDError("DETECTOR_TIMEOUT", "Automatic climax detection timed out.") from error
    except (OSError, ValueError, subprocess.CalledProcessError) as error:
        raise RNIDError("DETECTOR_ERROR", "Automatic climax detection failed.") from error


if __name__ == "__main__":
    from .climax import detect

    result = detect(np.load(sys.argv[1], mmap_mode="r", allow_pickle=False))
    print(json.dumps(result, allow_nan=False))
