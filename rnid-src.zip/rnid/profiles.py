"""Load and validate the JSON profiles available to a render."""

import hashlib
import json
import math
import os
import re
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType

from .errors import RNIDError


@dataclass(frozen=True)
class Profile:
    id: str
    version: str | int
    label: str
    provenance: str
    review_status: str
    left: Mapping
    right: Mapping
    model: Mapping
    digest: str

    def public(self) -> dict:
        return {
            "id": self.id,
            "version": self.version,
            "label": self.label,
            "review_status": self.review_status,
        }


def _text(value: object) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Expected nonempty text")
    return value


def _number(value: object) -> float:
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError("Expected a finite number")
    return float(value)


# MSBG models loss relative to 0 dB HL. A negative threshold gives an expansion ratio
# below 1, which inverts recruitment, and upstream flags levels above 80 dB HL as
# unrealistic. Record better-than-normal points as 0 dB HL.
MIN_THRESHOLD_DB_HL = 0.0
MAX_THRESHOLD_DB_HL = 80.0
# MSBG chooses its filterbank and smearing from the mean threshold at 2–8 kHz points.
SEVERITY_BAND_HZ = (2000.0, 8000.0)


def _audiogram(data: dict) -> Mapping:
    frequencies = tuple(map(_number, data["frequencies_hz"]))
    thresholds = tuple(map(_number, data["thresholds_db_hl"]))
    if len(frequencies) < 2 or len(frequencies) != len(thresholds):
        raise ValueError("Audiogram needs at least two frequencies and one threshold per frequency")
    if frequencies[0] <= 0 or frequencies[-1] > 22050:
        raise ValueError("Audiogram frequencies must lie between 0 and 22050 Hz")
    if any(a >= b for a, b in zip(frequencies, frequencies[1:])):
        raise ValueError("Audiogram frequencies must be strictly increasing")
    if not all(MIN_THRESHOLD_DB_HL <= value <= MAX_THRESHOLD_DB_HL for value in thresholds):
        raise ValueError(
            f"Thresholds must lie between {MIN_THRESHOLD_DB_HL:g} and {MAX_THRESHOLD_DB_HL:g} dB HL"
        )
    low, high = SEVERITY_BAND_HZ
    if not any(low <= frequency <= high for frequency in frequencies):
        raise ValueError("Audiogram needs at least one frequency from 2000 to 8000 Hz")
    return MappingProxyType({"frequencies_hz": frequencies, "thresholds_db_hl": thresholds})


def _unique_keys(pairs: list) -> dict:
    result = dict(pairs)
    if len(result) != len(pairs):
        raise ValueError("Duplicate JSON key")
    return result


def _read_profile(path: Path) -> Profile:
    try:
        return _parse_profile(path)
    except KeyError as error:
        raise ValueError(f"Missing field {error.args[0]!r}") from error
    except TypeError as error:
        raise ValueError("A field has the wrong type") from error


def read_profile(path: Path | str) -> Profile:
    """Validate one profile file under the registry rules, with the reason on failure."""
    path = Path(path)
    try:
        return _read_profile(path)
    except OSError as error:
        raise RNIDError("INVALID_PROFILE", f"{path.name}: the file could not be read.") from error
    except (ValueError, OverflowError) as error:
        raise RNIDError("INVALID_PROFILE", f"{path.name}: {error}.") from error


def _parse_profile(path: Path) -> Profile:
    raw = path.read_bytes()
    data = json.loads(raw, object_pairs_hook=_unique_keys)
    profile_id = _text(data["id"])
    if not re.fullmatch(r"[a-z][a-z0-9_]{0,63}", profile_id):
        raise ValueError("Invalid profile ID")
    version = data["version"]
    if type(version) is not int or version < 1:
        version = _text(version)
    model = data["model"]
    src_pos = model["src_pos"]
    if src_pos not in ("ff", "df", "ITU"):
        raise ValueError("Invalid MSBG source position")
    calibration = MappingProxyType({
        "src_pos": src_pos,
        "equiv_0db_spl": _number(model["equiv_0db_spl"]),
        "ahr": _number(model["ahr"]),
    })
    review_status = data["review_status"]
    if review_status not in ("engineering", "pending_review", "approved"):
        raise ValueError("Invalid profile review status")
    return Profile(
        id=profile_id,
        version=version,
        label=_text(data["label"]),
        provenance=_text(data["provenance"]),
        review_status=review_status,
        left=_audiogram(data["left"]),
        right=_audiogram(data["right"]),
        model=calibration,
        digest=hashlib.sha256(raw).hexdigest(),
    )


def load_registry() -> dict[str, Profile]:
    directory = Path(os.environ.get("RNID_PROFILE_DIR", Path(__file__).with_name("profile_data")))
    registry = {}
    for path in sorted(directory.glob("*.json")):
        try:
            profile = _read_profile(path)
            if profile.id in registry:
                raise ValueError("Duplicate profile ID")
        except (KeyError, TypeError, ValueError, OverflowError, OSError) as error:
            raise RNIDError("INVALID_PROFILE", f"Registry contains an invalid profile ({path.name}).") from error
        registry[profile.id] = profile
    if not registry:
        raise RNIDError("INVALID_PROFILE", "The profile registry is empty or unavailable.")
    return registry
