import os

from .audio import AudioLimits
from .errors import RNIDError


def limits_from_env() -> AudioLimits:
    defaults = AudioLimits()
    try:
        max_bytes = int(os.environ.get("RNID_MAX_BYTES", defaults.max_bytes))
        min_seconds = float(os.environ.get("RNID_MIN_SECONDS", defaults.min_seconds))
        max_seconds = float(os.environ.get("RNID_MAX_SECONDS", defaults.max_seconds))
        return AudioLimits(min_seconds=min_seconds, max_seconds=max_seconds, max_bytes=max_bytes)
    except (ValueError, OverflowError) as error:
        raise RNIDError("INVALID_CONFIG", "Audio limits must be positive and ordered.") from error
