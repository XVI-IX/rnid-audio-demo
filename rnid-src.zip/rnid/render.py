"""Produce and commit one complete comparison bundle."""

import json
import platform
import tempfile
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

import numpy as np
import scipy

from . import PYCLARITY_VERSION, __version__
from . import audio, filters, msbg
from .detection import analyse
from .errors import RNIDError
from .profiles import Profile


def _climax_result(
    reference: np.ndarray,
    automatic: bool,
    seconds: str | None,
    sample: str | None,
) -> dict:
    if seconds is None and sample is None:
        result = {
            "status": "disabled",
            "selected_by": None,
            "selected_sample": None,
            "selected_seconds": None,
            "candidates": [],
        }
        if automatic:
            try:
                return analyse(reference)
            except RNIDError as error:
                return {**result, "status": "error", "error_code": error.code}
        return result
    if seconds is not None and sample is not None:
        raise RNIDError("INVALID_MARKER", "Supply either a time or a sample index.")
    try:
        frames = len(reference)
        if seconds is None:
            index = int(sample)
        else:
            value = Decimal(seconds)
            if not value.is_finite() or not (0 <= value <= Decimal(frames) / audio.SAMPLE_RATE):
                raise ValueError
            index = int((value * audio.SAMPLE_RATE).to_integral_value(rounding=ROUND_HALF_UP))
        if not 0 <= index < frames:
            raise ValueError
    except (ValueError, InvalidOperation, OverflowError) as error:
        raise RNIDError("INVALID_MARKER", "The marker must be within the decoded audio.") from error
    return {
        "status": "ok",
        "selected_by": "manual",
        "selected_sample": index,
        "selected_seconds": index / audio.SAMPLE_RATE,
        "candidates": [],
    }


def _require_empty_output(directory: Path) -> None:
    if directory.is_symlink() or (directory.exists() and (
        not directory.is_dir() or any(directory.iterdir())
    )):
        raise RNIDError("OUTPUT_EXISTS", "The output path must be absent or an empty directory.")


def convert(
    source: Path,
    profile: Profile,
    out_dir: Path,
    *,
    limits: audio.AudioLimits = audio.AudioLimits(),
    detect_climax: bool = False,
    climax_seconds: str | None = None,
    climax_sample: str | None = None,
    include_filter: bool = False,
) -> dict:
    out_dir = out_dir.absolute()
    try:
        _require_empty_output(out_dir)
        out_dir.parent.mkdir(parents=True, exist_ok=True)
    except OSError as error:
        raise RNIDError("EXPORT_FAILED", "The output path is unavailable.") from error

    reference = audio.decode(source, limits)
    frames = len(reference)
    marker = _climax_result(reference, detect_climax, climax_seconds, climax_sample)
    simulated, details = msbg.render(reference, profile.left, profile.right, profile.model)
    warnings = []
    if profile.review_status != "approved":
        warnings.append("PROFILE_UNREVIEWED")
    if marker["status"] == "error":
        warnings.append(marker["error_code"])
    manifest = {
        "schema_version": "1.0",
        "audio": {
            "sample_rate_hz": audio.SAMPLE_RATE,
            "channels": 2,
            "frames": frames,
            "duration_seconds": frames / audio.SAMPLE_RATE,
            "reference": "reference.wav",
            "simulated": "simulated.wav",
        },
        "profile": {**profile.public(), "digest": f"sha256:{profile.digest}", "provenance": profile.provenance},
        "engine": {
            "name": "Cambridge MSBG",
            "rnid": __version__,
            "pyclarity": PYCLARITY_VERSION,
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "ffmpeg": audio.ffmpeg_version(),
        },
        "model": {"calibration": dict(profile.model), **details},
        "warnings": warnings,
        "climax": marker,
    }
    try:
        with tempfile.TemporaryDirectory(prefix=".rnid-render-", dir=out_dir.parent) as staging:
            bundle = Path(staging) / "bundle"
            bundle.mkdir(mode=0o700)
            manifest["level"] = audio.export_pair(reference, simulated, bundle)
            if include_filter:
                levels = filters.bundle_levels(details["input_rms_dbfs"], details["bypassed_silent"])
                impulse_response, info = filters.design(profile.left, profile.right, profile.model, levels)
                filters.write(bundle / filters.FILE_NAME, impulse_response)
                manifest["filter"] = {"file": filters.FILE_NAME, **info}
            (bundle / "manifest.json").write_text(
                json.dumps(manifest, indent=2, allow_nan=False) + "\n", encoding="utf-8"
            )
            _require_empty_output(out_dir)
            bundle.rename(out_dir)
    except OSError as error:
        raise RNIDError("EXPORT_FAILED", "The output bundle could not be committed.") from error
    return manifest
