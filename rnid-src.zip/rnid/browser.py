"""Render pipeline for the offline browser package (Pyodide): decoded PCM in, bundle out.

The browser decodes the file and resamples it to 44.1 kHz with Web Audio, so FFmpeg is not
needed. Everything after decoding is the converter's own code: the same MSBG adapter, level
convention, path compensation, marker validation, peak ceiling rule and manifest schema.
The differences are recorded in the manifest's ``engine`` section: the decoder, and a 4x
oversampled true-peak estimate in place of FFmpeg's ebur128 meter.
"""

from __future__ import annotations

import math
import platform
import sys

import numpy as np
import scipy
from scipy.signal import resample_poly

from . import PYCLARITY_VERSION, __version__, audio, filters, msbg
from .errors import RNIDError
from .profiles import load_registry
from .render import _climax_result

TRUE_PEAK_METER = "4x polyphase oversampling (scipy.signal.resample_poly)"


def profiles() -> list[dict]:
    """Registry profiles with display details, in registry order."""
    return [
        {**profile.public(), "provenance": profile.provenance, "digest": f"sha256:{profile.digest}",
         "severity": {side: msbg.severity(ear) for side, ear in (("left", profile.left), ("right", profile.right))}}
        for profile in load_registry().values()
    ]


def true_peak_dbtp(samples: np.ndarray) -> float | None:
    """Highest absolute value after 4x oversampling, in dBFS; None for digital silence."""
    peak = 0.0
    for channel in range(samples.shape[1]):
        peak = max(peak, float(np.max(np.abs(resample_poly(samples[:, channel], 4, 1)))))
    return 20 * math.log10(peak) if peak > 0 else None


def _canonical(channels: list[np.ndarray], sample_rate: int, limits: audio.AudioLimits) -> np.ndarray:
    if sample_rate != audio.SAMPLE_RATE:
        raise RNIDError("INVALID_AUDIO", f"Decode the audio at {audio.SAMPLE_RATE} Hz before rendering.")
    if len(channels) not in (1, 2) or len({len(channel) for channel in channels}) != 1:
        raise RNIDError("UNSUPPORTED_FORMAT", "Only mono and left/right stereo audio are supported.")
    frames = len(channels[0])
    if not limits.min_frames <= frames <= limits.max_frames:
        raise RNIDError(
            "DURATION_OUT_OF_RANGE",
            f"Decoded duration must be between {limits.min_seconds:g} and {limits.max_seconds:g} seconds.",
        )
    pcm = np.column_stack([np.asarray(channel, dtype=np.float32) for channel in channels])
    if not np.isfinite(pcm).all():
        raise RNIDError("INVALID_AUDIO", "The decoded audio contains non-finite samples.")
    return pcm if pcm.shape[1] == audio.CHANNELS else np.repeat(pcm, audio.CHANNELS, axis=1)


def _climax(reference: np.ndarray, detect_climax: bool, climax_seconds: str | None) -> dict:
    if climax_seconds is not None or not detect_climax:
        return _climax_result(reference, False, climax_seconds, None)
    # The converter runs the detector in a subprocess with a deadline; a browser has no
    # subprocesses, so it runs in this worker.
    from .climax import detect

    try:
        return detect(reference)
    except Exception:  # noqa: BLE001 - a detector failure must never cost the audio
        return {"status": "error", "error_code": "DETECTOR_ERROR", "selected_by": None,
                "selected_sample": None, "selected_seconds": None, "candidates": []}


def render(
    channels: list[np.ndarray],
    sample_rate: int,
    profile_id: str,
    *,
    climax_seconds: str | None = None,
    detect_climax: bool = False,
    include_filter: bool = False,
    decoder: str = "browser Web Audio",
    runtime: str = "",
) -> dict:
    """Return float32 reference and simulated arrays, an optional filter, and the manifest."""
    registry = load_registry()
    profile = registry.get(profile_id)
    if profile is None:
        raise RNIDError("INVALID_PROFILE", "The requested profile is unavailable.")
    reference = _canonical(channels, sample_rate, audio.AudioLimits())
    frames = len(reference)
    marker = _climax(reference, detect_climax, climax_seconds)
    simulated, details = msbg.render(reference, profile.left, profile.right, profile.model)

    pre_gain = {"reference": true_peak_dbtp(reference), "simulated": true_peak_dbtp(simulated)}
    louder = max((peak for peak in pre_gain.values() if peak is not None), default=-math.inf)
    gain_db = 0.0 if louder < audio.PEAK_CEILING_DBTP else audio.PEAK_CEILING_DBTP - audio.METER_MARGIN_DB - louder
    gain = 10 ** (gain_db / 20)
    outputs = {
        "reference": (reference.astype(np.float64) * gain).astype(np.float32),
        "simulated": (simulated * gain).astype(np.float32),
    }
    export_peaks = {name: true_peak_dbtp(samples) for name, samples in outputs.items()}

    warnings = [] if profile.review_status == "approved" else ["PROFILE_UNREVIEWED"]
    if marker["status"] == "error":
        warnings.append(marker.get("error_code", "DETECTOR_ERROR"))
    manifest = {
        "schema_version": "1.0",
        "audio": {
            "sample_rate_hz": audio.SAMPLE_RATE,
            "channels": audio.CHANNELS,
            "frames": frames,
            "duration_seconds": frames / audio.SAMPLE_RATE,
            "reference": "reference.wav",
            "simulated": "simulated.wav",
        },
        "profile": {**profile.public(), "digest": f"sha256:{profile.digest}", "provenance": profile.provenance},
        "engine": {
            "name": "Cambridge MSBG",
            "rnid": __version__,
            "pyclarity": PYCLARITY_VERSION,
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "runtime": runtime or f"python {sys.version.split()[0]} ({sys.platform})",
            "decoder": decoder,
        },
        "model": {"calibration": dict(profile.model), **details},
        "warnings": warnings,
        "climax": marker,
        "level": {
            "true_peak_ceiling_dbtp": audio.PEAK_CEILING_DBTP,
            "true_peak_meter": TRUE_PEAK_METER,
            "pre_gain_true_peak_dbtp": pre_gain,
            "export_true_peak_dbtp": export_peaks,
            "common_gain_db": gain_db,
            "common_gain_linear": gain,
        },
    }
    result = {**outputs, "manifest": manifest}
    if include_filter:
        levels = filters.bundle_levels(details["input_rms_dbfs"], details["bypassed_silent"])
        response, info = filters.design(profile.left, profile.right, profile.model, levels)
        result["filter"] = np.asarray(response, dtype=np.float32)
        manifest["filter"] = {"file": filters.FILE_NAME, **info}
    return result
